package br.unirio.cloudeco;

import java.io.File;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.formats.RDFXMLDocumentFormat;
import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLClassExpression;
import org.semanticweb.owlapi.model.OWLDataFactory;
import org.semanticweb.owlapi.model.OWLDataProperty;
import org.semanticweb.owlapi.model.OWLDocumentFormat;
import org.semanticweb.owlapi.model.OWLLiteral;
import org.semanticweb.owlapi.model.OWLNamedIndividual;
import org.semanticweb.owlapi.model.OWLObjectProperty;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyCreationException;
import org.semanticweb.owlapi.model.OWLOntologyManager;
import org.semanticweb.owlapi.util.DefaultPrefixManager;

/**
 * CloudEco-Ontology
 * 
 * Ontologia para Ecossistemas de Computação em Nuvem
 * 
 * Baseada no artigo: "The Evolution of Cloud Ecosystems: 
 * How AWS, Azure, and GCP Transformed Between 2008 and 2025"
 * Autores: Arruda, Santos, Moura, Alvim, Moraes (2025)
 * 
 * Referências principais:
 * - Arruda et al. (2025) - Evolução de ecossistemas de nuvem no Stack Overflow
 * - Mell e Grance (2011) - Definição NIST de computação em nuvem
 * - Armbrust et al. (2010) - Modelos de serviço em nuvem
 * 
 * Questões de Competência respondidas pela ontologia:
 * QC1 - O que é um ecossistema de nuvem?
 * QC2 - Quais são os principais modelos de serviço em nuvem?
 * QC3 - Quais paradigmas tecnológicos emergiram?
 * QC4 - Quais são os serviços centrais da AWS?
 * QC5 - Quais são os serviços centrais da Azure?
 * QC6 - Quais são os serviços centrais da GCP?
 * QC7 - Como as comunidades interagem com as plataformas?
 * QC8 - Quais fatores influenciam a evolução?
 * QC9 - Como a governança é exercida?
 * QC10 - Quais são as diferenças evolutivas?
 * QC11 - Como a IA generativa está influenciando?
 * QC12 - Quais métodos são utilizados para analisar?
 * 
 * @author Roberto Monteiro Dias
 */
public class CloudEcoOntology {

    private static final String NS = "http://www.unirio.br/cloudeco/ontology#";
    private static final String BASE = "http://www.unirio.br/cloudeco/ontology";
    private static final String OUTPUT_DIR = "D:/EclipseView/workspace/CloudEco-Ontology/ontology/";

    private static final String ANSI_RESET = "\u001B[0m";
    private static final String ANSI_BOLD = "\u001B[1m";
    private static final String ANSI_CYAN = "\u001B[36m";
    private static final String ANSI_GREEN = "\u001B[32m";
    private static final String ANSI_YELLOW = "\u001B[33m";
    private static final String ANSI_RED = "\u001B[31m";

    private OWLOntologyManager manager;
    private OWLOntology ontology;
    private OWLDataFactory factory;
    private DefaultPrefixManager prefixManager;

    // ============================================================
    // CLASSES - NÚCLEO
    // ============================================================
    private OWLClass classEcossistemaNuvem;
    private OWLClass classPlataformaNuvem;
    private OWLClass classAtor;
    private OWLClass classKeystone;
    private OWLClass classIntegrador;
    private OWLClass classDesenvolvedor;
    private OWLClass classUsuarioFinal;

    // ============================================================
    // CLASSES - MODELOS DE SERVIÇO
    // ============================================================
    private OWLClass classModeloServico;
    private OWLClass classIaaS;
    private OWLClass classPaaS;
    private OWLClass classSaaS;

    // ============================================================
    // CLASSES - PARADIGMAS TECNOLÓGICOS (Ondas Temáticas)
    // ============================================================
    private OWLClass classParadigmaTecnologico;
    private OWLClass classVirtualizacao;
    private OWLClass classServicosGerenciados;
    private OWLClass classContainersServerless;
    private OWLClass classEngenhariaDados;
    private OWLClass classIAGenerativa;

    // ============================================================
    // CLASSES - SERVIÇOS AWS
    // ============================================================
    private OWLClass classServicoAWS;
    private OWLClass classAmazonEC2;
    private OWLClass classAmazonS3;
    private OWLClass classAWSLambda;
    private OWLClass classAmazonDynamoDB;
    private OWLClass classAmazonRDS;
    private OWLClass classAmazonCloudFront;
    private OWLClass classAWSGlue;
    private OWLClass classAWSAppSync;
    private OWLClass classAWSSDK;
    private OWLClass classCloudFormation;
    private OWLClass classTerraform;
    private OWLClass classAmazonBedrock;
    private OWLClass classAWSCognito;
    private OWLClass classAWSAmplify;
    private OWLClass classAmazonElasticBeanstalk;
    private OWLClass classAmazonAPIGateway;
    private OWLClass classAWSServerless;

    // ============================================================
    // CLASSES - SERVIÇOS AZURE
    // ============================================================
    private OWLClass classServicoAzure;
    private OWLClass classAzureDevOps;
    private OWLClass classAzureFunctions;
    private OWLClass classAzureDataFactory;
    private OWLClass classAzureActiveDirectory;
    private OWLClass classAzureSQLDatabase;
    private OWLClass classAzureStorage;
    private OWLClass classAzureWebAppService;
    private OWLClass classAzureCosmosDB;
    private OWLClass classAzurePipelines;
    private OWLClass classAzureOpenAI;
    private OWLClass classAzureSynapseAnalytics;
    private OWLClass classAzureBicep;
    private OWLClass classAzureDatabricks;
    private OWLClass classAzureMobileServices;
    private OWLClass classAzureAKS;

    // ============================================================
    // CLASSES - SERVIÇOS GCP
    // ============================================================
    private OWLClass classServicoGCP;
    private OWLClass classGoogleAppEngine;
    private OWLClass classFirebase;
    private OWLClass classGoogleCloudFirestore;
    private OWLClass classFlutter;
    private OWLClass classGoogleCloudDatastore;
    private OWLClass classGoogleCloudStorage;
    private OWLClass classGoogleCloudFunctions;
    private OWLClass classGoogleCloudEndpoints;
    private OWLClass classGoogleCloudSQL;
    private OWLClass classGoogleCloudDataProc;
    private OWLClass classApacheBeam;
    private OWLClass classGoogleCloudVertexAI;
    private OWLClass classGoogleGemini;
    private OWLClass classLangChain;
    private OWLClass classGoogleCloudMessaging;
    private OWLClass classKubernetes;

    // ============================================================
    // CLASSES - COMUNIDADE E GOVERNANÇA
    // ============================================================
    private OWLClass classComunidadeDesenvolvedores;
    private OWLClass classStackOverflow;
    private OWLClass classGovernanca;
    private OWLClass classContratoTecnico;
    private OWLClass classContratoComercial;
    private OWLClass classAPI;
    private OWLClass classSLA;

    // ============================================================
    // CLASSES - MÉTODOS E FERRAMENTAS
    // ============================================================
    private OWLClass classMetodoAnalise;
    private OWLClass classLDA;
    private OWLClass classMineraçãoDados;
    private OWLClass classAnaliseTendencias;
    private OWLClass classAnaliseTags;
    private OWLClass classGQM;

    // ============================================================
    // PROPRIEDADES DE OBJETO
    // ============================================================
    private OWLObjectProperty propOfereceServico;
    private OWLObjectProperty propAdotaParadigma;
    private OWLObjectProperty propPossuiModeloServico;
    private OWLObjectProperty propPossuiComunidade;
    private OWLObjectProperty propPossuiGovernanca;
    private OWLObjectProperty propInterageEm;
    private OWLObjectProperty propEvoluiPara;
    private OWLObjectProperty propInfluencia;
    private OWLObjectProperty propPertenceA;
    private OWLObjectProperty propGeraValor;
    private OWLObjectProperty propCoordena;
    private OWLObjectProperty propUtilizaAPI;
    private OWLObjectProperty propPossuiSLA;
    private OWLObjectProperty propEnvolveAtor;
    private OWLObjectProperty propTemParadigma;
    private OWLObjectProperty propSurgeEm;
    private OWLObjectProperty propUtilizaMetodo;
    private OWLObjectProperty propDocumentadoEm;
    private OWLObjectProperty propCategoriaDe;

    // ============================================================
    // PROPRIEDADES DE DADOS
    // ============================================================
    private OWLDataProperty dphHasName;
    private OWLDataProperty dphHasDescription;
    private OWLDataProperty dphHasLaunchYear;
    private OWLDataProperty dphHasMarketShare;
    private OWLDataProperty dphHasQuestionVolume;
    private OWLDataProperty dphHasTimeWindow;
    private OWLDataProperty dphHasServiceType;
    private OWLDataProperty dphHasReference;
    private OWLDataProperty dphHasStudyCount;
    private OWLDataProperty dphHasAuthors;
    private OWLDataProperty dphHasCategory;
    private OWLDataProperty dphHasAdoptionLevel;
    private OWLDataProperty dphHasTag;
    private OWLDataProperty dphHasPeriodo;
    private OWLDataProperty dphHasImpacto;

    public CloudEcoOntology() {
        try {
            this.manager = OWLManager.createOWLOntologyManager();
            this.factory = manager.getOWLDataFactory();

            this.prefixManager = new DefaultPrefixManager(NS);
            prefixManager.setPrefix("owl", "http://www.w3.org/2002/07/owl#");
            prefixManager.setPrefix("rdf", "http://www.w3.org/1999/02/22-rdf-syntax-ns#");
            prefixManager.setPrefix("rdfs", "http://www.w3.org/2000/01/rdf-schema#");
            prefixManager.setPrefix("xsd", "http://www.w3.org/2001/XMLSchema#");

            IRI ontologyIRI = IRI.create(BASE);
            this.ontology = manager.createOntology(ontologyIRI);

            System.out.println(ANSI_CYAN + "╔═══════════════════════════════════════════════════════════════════════════════╗" + ANSI_RESET);
            System.out.println(ANSI_CYAN + "║" + ANSI_BOLD + "  ☁️ CloudEco-Ontology v2.0 (Completa)" + ANSI_RESET + ANSI_CYAN + "                                          ║" + ANSI_RESET);
            System.out.println(ANSI_CYAN + "║  📚 Baseado no artigo: Arruda et al. (2025)" + ANSI_CYAN + "                                           ║" + ANSI_RESET);
            System.out.println(ANSI_CYAN + "║  📖 The Evolution of Cloud Ecosystems: AWS, Azure, and GCP (2008-2025)" + ANSI_CYAN + "     ║" + ANSI_RESET);
            System.out.println(ANSI_CYAN + "║  ❓ 12 Questões de Competência" + ANSI_CYAN + "                                                         ║" + ANSI_RESET);
            System.out.println(ANSI_CYAN + "╚═══════════════════════════════════════════════════════════════════════════════╝" + ANSI_RESET);

            build();
            System.out.println(ANSI_GREEN + "\n✅ Ontologia construída com sucesso!" + ANSI_RESET);

        } catch (OWLOntologyCreationException e) {
            e.printStackTrace();
        }
    }

    private void build() {
        createClasses();
        defineClassHierarchy();
        createObjectProperties();
        createDataProperties();
        createIndividuals();
        addAxioms();
    }

    // ============================================================
    // CRIAÇÃO DE CLASSES
    // ============================================================
    private void createClasses() {
        // Núcleo
        classEcossistemaNuvem = createClass("EcossistemaNuvem");
        classPlataformaNuvem = createClass("PlataformaNuvem");
        classAtor = createClass("Ator");
        classKeystone = createClass("Keystone");
        classIntegrador = createClass("Integrador");
        classDesenvolvedor = createClass("Desenvolvedor");
        classUsuarioFinal = createClass("UsuarioFinal");

        // Modelos de Serviço
        classModeloServico = createClass("ModeloServico");
        classIaaS = createClass("IaaS");
        classPaaS = createClass("PaaS");
        classSaaS = createClass("SaaS");

        // Paradigmas Tecnológicos
        classParadigmaTecnologico = createClass("ParadigmaTecnologico");
        classVirtualizacao = createClass("Virtualizacao");
        classServicosGerenciados = createClass("ServicosGerenciados");
        classContainersServerless = createClass("ContainersServerless");
        classEngenhariaDados = createClass("EngenhariaDados");
        classIAGenerativa = createClass("IAGenerativa");

        // Serviços AWS
        classServicoAWS = createClass("ServicoAWS");
        classAmazonEC2 = createClass("AmazonEC2");
        classAmazonS3 = createClass("AmazonS3");
        classAWSLambda = createClass("AWSLambda");
        classAmazonDynamoDB = createClass("AmazonDynamoDB");
        classAmazonRDS = createClass("AmazonRDS");
        classAmazonCloudFront = createClass("AmazonCloudFront");
        classAWSGlue = createClass("AWSGlue");
        classAWSAppSync = createClass("AWSAppSync");
        classAWSSDK = createClass("AWSSDK");
        classCloudFormation = createClass("CloudFormation");
        classTerraform = createClass("Terraform");
        classAmazonBedrock = createClass("AmazonBedrock");
        classAWSCognito = createClass("AWSCognito");
        classAWSAmplify = createClass("AWSAmplify");
        classAmazonElasticBeanstalk = createClass("AmazonElasticBeanstalk");
        classAmazonAPIGateway = createClass("AmazonAPIGateway");
        classAWSServerless = createClass("AWSServerless");

        // Serviços Azure
        classServicoAzure = createClass("ServicoAzure");
        classAzureDevOps = createClass("AzureDevOps");
        classAzureFunctions = createClass("AzureFunctions");
        classAzureDataFactory = createClass("AzureDataFactory");
        classAzureActiveDirectory = createClass("AzureActiveDirectory");
        classAzureSQLDatabase = createClass("AzureSQLDatabase");
        classAzureStorage = createClass("AzureStorage");
        classAzureWebAppService = createClass("AzureWebAppService");
        classAzureCosmosDB = createClass("AzureCosmosDB");
        classAzurePipelines = createClass("AzurePipelines");
        classAzureOpenAI = createClass("AzureOpenAI");
        classAzureSynapseAnalytics = createClass("AzureSynapseAnalytics");
        classAzureBicep = createClass("AzureBicep");
        classAzureDatabricks = createClass("AzureDatabricks");
        classAzureMobileServices = createClass("AzureMobileServices");
        classAzureAKS = createClass("AzureAKS");

        // Serviços GCP
        classServicoGCP = createClass("ServicoGCP");
        classGoogleAppEngine = createClass("GoogleAppEngine");
        classFirebase = createClass("Firebase");
        classGoogleCloudFirestore = createClass("GoogleCloudFirestore");
        classFlutter = createClass("Flutter");
        classGoogleCloudDatastore = createClass("GoogleCloudDatastore");
        classGoogleCloudStorage = createClass("GoogleCloudStorage");
        classGoogleCloudFunctions = createClass("GoogleCloudFunctions");
        classGoogleCloudEndpoints = createClass("GoogleCloudEndpoints");
        classGoogleCloudSQL = createClass("GoogleCloudSQL");
        classGoogleCloudDataProc = createClass("GoogleCloudDataProc");
        classApacheBeam = createClass("ApacheBeam");
        classGoogleCloudVertexAI = createClass("GoogleCloudVertexAI");
        classGoogleGemini = createClass("GoogleGemini");
        classLangChain = createClass("LangChain");
        classGoogleCloudMessaging = createClass("GoogleCloudMessaging");
        classKubernetes = createClass("Kubernetes");

        // Comunidade e Governança
        classComunidadeDesenvolvedores = createClass("ComunidadeDesenvolvedores");
        classStackOverflow = createClass("StackOverflow");
        classGovernanca = createClass("Governanca");
        classContratoTecnico = createClass("ContratoTecnico");
        classContratoComercial = createClass("ContratoComercial");
        classAPI = createClass("API");
        classSLA = createClass("SLA");

        // Métodos e Ferramentas
        classMetodoAnalise = createClass("MetodoAnalise");
        classLDA = createClass("LDA");
        classMineraçãoDados = createClass("MineracaoDados");
        classAnaliseTendencias = createClass("AnaliseTendencias");
        classAnaliseTags = createClass("AnaliseTags");
        classGQM = createClass("GQM");
    }

    private void defineClassHierarchy() {
        // Núcleo
        addSubClass(classKeystone, classAtor);
        addSubClass(classIntegrador, classAtor);
        addSubClass(classDesenvolvedor, classAtor);
        addSubClass(classUsuarioFinal, classAtor);

        // Modelos de Serviço
        addSubClass(classIaaS, classModeloServico);
        addSubClass(classPaaS, classModeloServico);
        addSubClass(classSaaS, classModeloServico);

        // Paradigmas Tecnológicos
        addSubClass(classVirtualizacao, classParadigmaTecnologico);
        addSubClass(classServicosGerenciados, classParadigmaTecnologico);
        addSubClass(classContainersServerless, classParadigmaTecnologico);
        addSubClass(classEngenhariaDados, classParadigmaTecnologico);
        addSubClass(classIAGenerativa, classParadigmaTecnologico);

        // Serviços AWS
        addSubClass(classAmazonEC2, classServicoAWS);
        addSubClass(classAmazonS3, classServicoAWS);
        addSubClass(classAWSLambda, classServicoAWS);
        addSubClass(classAmazonDynamoDB, classServicoAWS);
        addSubClass(classAmazonRDS, classServicoAWS);
        addSubClass(classAmazonCloudFront, classServicoAWS);
        addSubClass(classAWSGlue, classServicoAWS);
        addSubClass(classAWSAppSync, classServicoAWS);
        addSubClass(classAWSSDK, classServicoAWS);
        addSubClass(classCloudFormation, classServicoAWS);
        addSubClass(classTerraform, classServicoAWS);
        addSubClass(classAmazonBedrock, classServicoAWS);
        addSubClass(classAWSCognito, classServicoAWS);
        addSubClass(classAWSAmplify, classServicoAWS);
        addSubClass(classAmazonElasticBeanstalk, classServicoAWS);
        addSubClass(classAmazonAPIGateway, classServicoAWS);
        addSubClass(classAWSServerless, classServicoAWS);

        // Serviços Azure
        addSubClass(classAzureDevOps, classServicoAzure);
        addSubClass(classAzureFunctions, classServicoAzure);
        addSubClass(classAzureDataFactory, classServicoAzure);
        addSubClass(classAzureActiveDirectory, classServicoAzure);
        addSubClass(classAzureSQLDatabase, classServicoAzure);
        addSubClass(classAzureStorage, classServicoAzure);
        addSubClass(classAzureWebAppService, classServicoAzure);
        addSubClass(classAzureCosmosDB, classServicoAzure);
        addSubClass(classAzurePipelines, classServicoAzure);
        addSubClass(classAzureOpenAI, classServicoAzure);
        addSubClass(classAzureSynapseAnalytics, classServicoAzure);
        addSubClass(classAzureBicep, classServicoAzure);
        addSubClass(classAzureDatabricks, classServicoAzure);
        addSubClass(classAzureMobileServices, classServicoAzure);
        addSubClass(classAzureAKS, classServicoAzure);

        // Serviços GCP
        addSubClass(classGoogleAppEngine, classServicoGCP);
        addSubClass(classFirebase, classServicoGCP);
        addSubClass(classGoogleCloudFirestore, classServicoGCP);
        addSubClass(classFlutter, classServicoGCP);
        addSubClass(classGoogleCloudDatastore, classServicoGCP);
        addSubClass(classGoogleCloudStorage, classServicoGCP);
        addSubClass(classGoogleCloudFunctions, classServicoGCP);
        addSubClass(classGoogleCloudEndpoints, classServicoGCP);
        addSubClass(classGoogleCloudSQL, classServicoGCP);
        addSubClass(classGoogleCloudDataProc, classServicoGCP);
        addSubClass(classApacheBeam, classServicoGCP);
        addSubClass(classGoogleCloudVertexAI, classServicoGCP);
        addSubClass(classGoogleGemini, classServicoGCP);
        addSubClass(classLangChain, classServicoGCP);
        addSubClass(classGoogleCloudMessaging, classServicoGCP);
        addSubClass(classKubernetes, classServicoGCP);

        // Comunidade e Governança
        addSubClass(classStackOverflow, classComunidadeDesenvolvedores);
        addSubClass(classContratoTecnico, classGovernanca);
        addSubClass(classContratoComercial, classGovernanca);
        addSubClass(classAPI, classGovernanca);
        addSubClass(classSLA, classGovernanca);

        // Métodos
        addSubClass(classLDA, classMetodoAnalise);
        addSubClass(classMineraçãoDados, classMetodoAnalise);
        addSubClass(classAnaliseTendencias, classMetodoAnalise);
        addSubClass(classAnaliseTags, classMetodoAnalise);
        addSubClass(classGQM, classMetodoAnalise);
    }

    private void createObjectProperties() {
        propOfereceServico = createObjectProperty("ofereceServico");
        propAdotaParadigma = createObjectProperty("adotaParadigma");
        propPossuiModeloServico = createObjectProperty("possuiModeloServico");
        propPossuiComunidade = createObjectProperty("possuiComunidade");
        propPossuiGovernanca = createObjectProperty("possuiGovernanca");
        propInterageEm = createObjectProperty("interageEm");
        propEvoluiPara = createObjectProperty("evoluiPara");
        propInfluencia = createObjectProperty("influencia");
        propPertenceA = createObjectProperty("pertenceA");
        propGeraValor = createObjectProperty("geraValor");
        propCoordena = createObjectProperty("coordena");
        propUtilizaAPI = createObjectProperty("utilizaAPI");
        propPossuiSLA = createObjectProperty("possuiSLA");
        propEnvolveAtor = createObjectProperty("envolveAtor");
        propTemParadigma = createObjectProperty("temParadigma");
        propSurgeEm = createObjectProperty("surgeEm");
        propUtilizaMetodo = createObjectProperty("utilizaMetodo");
        propDocumentadoEm = createObjectProperty("documentadoEm");
        propCategoriaDe = createObjectProperty("categoriaDe");
    }

    private void createDataProperties() {
        dphHasName = createDataProperty("hasName");
        dphHasDescription = createDataProperty("hasDescription");
        dphHasLaunchYear = createDataProperty("hasLaunchYear");
        dphHasMarketShare = createDataProperty("hasMarketShare");
        dphHasQuestionVolume = createDataProperty("hasQuestionVolume");
        dphHasTimeWindow = createDataProperty("hasTimeWindow");
        dphHasServiceType = createDataProperty("hasServiceType");
        dphHasReference = createDataProperty("hasReference");
        dphHasStudyCount = createDataProperty("hasStudyCount");
        dphHasAuthors = createDataProperty("hasAuthors");
        dphHasCategory = createDataProperty("hasCategory");
        dphHasAdoptionLevel = createDataProperty("hasAdoptionLevel");
        dphHasTag = createDataProperty("hasTag");
        dphHasPeriodo = createDataProperty("hasPeriodo");
        dphHasImpacto = createDataProperty("hasImpacto");
    }

    // ============================================================
    // CRIAÇÃO DE INDIVÍDUOS - COMPLETA
    // ============================================================
    private void createIndividuals() {
        createCoreIndividuals();
        createModeloServicoIndividuals();
        createPlatformIndividuals();
        createParadigmIndividuals();
        createAWSServiceIndividuals();
        createAzureServiceIndividuals();
        createGCPServiceIndividuals();
        createCommunityIndividuals();
        createGovernancaIndividuals();
        createMetodoIndividuals();
        createFatoresEvolucao();
        createDiferencasEvolutivas();
        createIAGenerativaImpacto();
        createRelationships();
    }

    // ============================================================
    // QC1 - O que é um ecossistema de nuvem?
    // ============================================================
    private void createCoreIndividuals() {
        // Ecossistema de Nuvem
        OWLNamedIndividual eco1 = createIndividual("Ecossistema_Cloud", classEcossistemaNuvem);
        addDataProperty(eco1, dphHasName, "Ecossistema de Computação em Nuvem");
        addDataProperty(eco1, dphHasDescription, "Sistema sociotécnico composto por plataforma tecnológica, atores e relacionamentos. Envolve componentes (IaaS, PaaS, SaaS), atores (keystones, integradores, desenvolvedores, usuários finais) e relações (contratos técnicos e comerciais).");
        addDataProperty(eco1, dphHasReference, "Messerschmitt e Szyperski, 2003; Barbosa et al., 2013; Arruda et al., 2025");
        addDataProperty(eco1, dphHasAuthors, "Arruda, Santos, Moura, Alvim, Moraes");

        // Atores do Ecossistema
        OWLNamedIndividual keystone = createIndividual("Ator_Keystone", classKeystone);
        addDataProperty(keystone, dphHasName, "Keystone");
        addDataProperty(keystone, dphHasDescription, "Organização central que coordena o ecossistema (ex: AWS, Azure, GCP)");
        addDataProperty(keystone, dphHasReference, "Barbosa et al., 2013");

        OWLNamedIndividual integrador = createIndividual("Ator_Integrador", classIntegrador);
        addDataProperty(integrador, dphHasName, "Integrador");
        addDataProperty(integrador, dphHasDescription, "Ator que integra diferentes componentes e serviços do ecossistema");
        addDataProperty(integrador, dphHasReference, "Barbosa et al., 2013");

        OWLNamedIndividual desenvolvedor = createIndividual("Ator_Desenvolvedor", classDesenvolvedor);
        addDataProperty(desenvolvedor, dphHasName, "Desenvolvedor");
        addDataProperty(desenvolvedor, dphHasDescription, "Profissional que utiliza serviços de nuvem para desenvolver aplicações");
        addDataProperty(desenvolvedor, dphHasReference, "Arruda et al., 2025");

        OWLNamedIndividual usuarioFinal = createIndividual("Ator_UsuarioFinal", classUsuarioFinal);
        addDataProperty(usuarioFinal, dphHasName, "Usuário Final");
        addDataProperty(usuarioFinal, dphHasDescription, "Consumidor final das aplicações hospedadas na nuvem");
        addDataProperty(usuarioFinal, dphHasReference, "Barbosa et al., 2013");

        // Conecta atores ao ecossistema
        addObjectProperty(eco1, propEnvolveAtor, keystone);
        addObjectProperty(eco1, propEnvolveAtor, integrador);
        addObjectProperty(eco1, propEnvolveAtor, desenvolvedor);
        addObjectProperty(eco1, propEnvolveAtor, usuarioFinal);
    }

    // ============================================================
    // QC2 - Quais são os principais modelos de serviço em nuvem?
    // ============================================================
    private void createModeloServicoIndividuals() {
        OWLNamedIndividual iaas = createIndividual("IaaS", classIaaS);
        addDataProperty(iaas, dphHasName, "Infraestrutura como Serviço (IaaS)");
        addDataProperty(iaas, dphHasDescription, "Provê recursos básicos de computação: máquinas virtuais, armazenamento e redes. Permite ao usuário instalar sistemas operacionais e middleware.");
        addDataProperty(iaas, dphHasReference, "Armbrust et al., 2010; Mell e Grance, 2011");

        OWLNamedIndividual paas = createIndividual("PaaS", classPaaS);
        addDataProperty(paas, dphHasName, "Plataforma como Serviço (PaaS)");
        addDataProperty(paas, dphHasDescription, "Oferece ambientes pré-configurados para desenvolvimento, teste e implantação de aplicações, abstraindo a infraestrutura subjacente.");
        addDataProperty(paas, dphHasReference, "Zhang, Cheng e Boutaba, 2010");

        OWLNamedIndividual saas = createIndividual("SaaS", classSaaS);
        addDataProperty(saas, dphHasName, "Software como Serviço (SaaS)");
        addDataProperty(saas, dphHasDescription, "Disponibiliza produtos de software completos via navegador ou API, sem necessidade de instalação local.");
        addDataProperty(saas, dphHasReference, "Marston et al., 2011");
    }

    // ============================================================
    // QC3 - Quais paradigmas tecnológicos emergiram?
    // ============================================================
    private void createParadigmIndividuals() {
        OWLNamedIndividual p1 = createIndividual("Paradigma_Virtualizacao", classVirtualizacao);
        addDataProperty(p1, dphHasName, "Virtualização e IaaS");
        addDataProperty(p1, dphHasDescription, "Provisionamento de máquinas virtuais, armazenamento e autenticação. Foco em disponibilidade e segurança.");
        addDataProperty(p1, dphHasTimeWindow, "2008-2012");
        addDataProperty(p1, dphHasReference, "Arruda et al., 2025");
        addDataProperty(p1, dphHasTag, "EC2, S3, armazenamento, autenticação");

        OWLNamedIndividual p2 = createIndividual("Paradigma_ServicosGerenciados", classServicosGerenciados);
        addDataProperty(p2, dphHasName, "Serviços Gerenciados e PaaS");
        addDataProperty(p2, dphHasDescription, "Consolidação de serviços gerenciados e orquestração por templates. Deslocamento do foco operacional para padronização de ambientes.");
        addDataProperty(p2, dphHasTimeWindow, "2013-2016");
        addDataProperty(p2, dphHasReference, "Arruda et al., 2025");
        addDataProperty(p2, dphHasTag, "Elastic Beanstalk, Azure Mobile Services, App Engine");

        OWLNamedIndividual p3 = createIndividual("Paradigma_ContainersServerless", classContainersServerless);
        addDataProperty(p3, dphHasName, "Contêineres e Serverless");
        addDataProperty(p3, dphHasDescription, "Automação, conteinerização, serverless e infraestrutura como código. Pipelines CI/CD como pilares da cultura DevOps.");
        addDataProperty(p3, dphHasTimeWindow, "2017-2019");
        addDataProperty(p3, dphHasReference, "Arruda et al., 2025");
        addDataProperty(p3, dphHasTag, "Docker, Lambda, Kubernetes, Terraform");

        OWLNamedIndividual p4 = createIndividual("Paradigma_EngenhariaDados", classEngenhariaDados);
        addDataProperty(p4, dphHasName, "Engenharia de Dados e MLOps");
        addDataProperty(p4, dphHasDescription, "Workloads analíticos e aprendizado de máquina. Consolidação das nuvens como suporte a workloads analíticos.");
        addDataProperty(p4, dphHasTimeWindow, "2020-2022");
        addDataProperty(p4, dphHasReference, "Arruda et al., 2025");
        addDataProperty(p4, dphHasTag, "Spark, Data Factory, Vertex AI, MLOps");

        OWLNamedIndividual p5 = createIndividual("Paradigma_IAGenerativa", classIAGenerativa);
        addDataProperty(p5, dphHasName, "IA Generativa e Copilots");
        addDataProperty(p5, dphHasDescription, "Soluções IA-driven, RAG, copilots e serviços cognitivos. Preocupações com latência e governança de modelos.");
        addDataProperty(p5, dphHasTimeWindow, "2023-2025");
        addDataProperty(p5, dphHasReference, "Arruda et al., 2025");
        addDataProperty(p5, dphHasTag, "Bedrock, OpenAI, Gemini, LangChain, RAG");

        // Evolução dos paradigmas
        addObjectProperty(p1, propEvoluiPara, p2);
        addObjectProperty(p2, propEvoluiPara, p3);
        addObjectProperty(p3, propEvoluiPara, p4);
        addObjectProperty(p4, propEvoluiPara, p5);
    }

    // ============================================================
    // QC3 e QC10 - Plataformas e seus paradigmas
    // ============================================================
    private void createPlatformIndividuals() {
        // AWS
        OWLNamedIndividual aws = createIndividual("Plataforma_AWS", classPlataformaNuvem);
        addDataProperty(aws, dphHasName, "Amazon Web Services (AWS)");
        addDataProperty(aws, dphHasDescription, "Plataforma de nuvem pioneira, lançada em 2006 com EC2 e S3. Evoluiu de infraestrutura básica para um ecossistema orientado à automação e orquestração.");
        addDataProperty(aws, dphHasLaunchYear, "2006");
        addDataProperty(aws, dphHasMarketShare, "32%");
        addDataProperty(aws, dphHasReference, "Arruda et al., 2025");
        addDataProperty(aws, dphHasAuthors, "Amazon");

        // Azure
        OWLNamedIndividual azure = createIndividual("Plataforma_Azure", classPlataformaNuvem);
        addDataProperty(azure, dphHasName, "Microsoft Azure");
        addDataProperty(azure, dphHasDescription, "Plataforma de nuvem da Microsoft, lançada em 2010 como Windows Azure. Consolidou-se como plataforma corporativa com ênfase em identidade, compliance e governança.");
        addDataProperty(azure, dphHasLaunchYear, "2010");
        addDataProperty(azure, dphHasMarketShare, "23%");
        addDataProperty(azure, dphHasReference, "Arruda et al., 2025");
        addDataProperty(azure, dphHasAuthors, "Microsoft");

        // GCP
        OWLNamedIndividual gcp = createIndividual("Plataforma_GCP", classPlataformaNuvem);
        addDataProperty(gcp, dphHasName, "Google Cloud Platform (GCP)");
        addDataProperty(gcp, dphHasDescription, "Plataforma de nuvem do Google, estruturada a partir de 2011. Destacou-se pela produtividade do desenvolvedor, serverless e inovação em engenharia de dados e IA.");
        addDataProperty(gcp, dphHasLaunchYear, "2011");
        addDataProperty(gcp, dphHasMarketShare, "11%");
        addDataProperty(gcp, dphHasReference, "Arruda et al., 2025");
        addDataProperty(gcp, dphHasAuthors, "Google");

        // Modelos de Serviço para cada plataforma
        addObjectProperty(aws, propPossuiModeloServico, getIndividual("IaaS"));
        addObjectProperty(aws, propPossuiModeloServico, getIndividual("PaaS"));
        addObjectProperty(aws, propPossuiModeloServico, getIndividual("SaaS"));

        addObjectProperty(azure, propPossuiModeloServico, getIndividual("IaaS"));
        addObjectProperty(azure, propPossuiModeloServico, getIndividual("PaaS"));
        addObjectProperty(azure, propPossuiModeloServico, getIndividual("SaaS"));

        addObjectProperty(gcp, propPossuiModeloServico, getIndividual("IaaS"));
        addObjectProperty(gcp, propPossuiModeloServico, getIndividual("PaaS"));
        addObjectProperty(gcp, propPossuiModeloServico, getIndividual("SaaS"));

        // Paradigmas adotados por cada plataforma
        OWLNamedIndividual p1 = getIndividual("Paradigma_Virtualizacao");
        OWLNamedIndividual p2 = getIndividual("Paradigma_ServicosGerenciados");
        OWLNamedIndividual p3 = getIndividual("Paradigma_ContainersServerless");
        OWLNamedIndividual p4 = getIndividual("Paradigma_EngenhariaDados");
        OWLNamedIndividual p5 = getIndividual("Paradigma_IAGenerativa");

        addObjectProperty(aws, propAdotaParadigma, p1);
        addObjectProperty(aws, propAdotaParadigma, p2);
        addObjectProperty(aws, propAdotaParadigma, p3);
        addObjectProperty(aws, propAdotaParadigma, p4);
        addObjectProperty(aws, propAdotaParadigma, p5);

        addObjectProperty(azure, propAdotaParadigma, p1);
        addObjectProperty(azure, propAdotaParadigma, p2);
        addObjectProperty(azure, propAdotaParadigma, p3);
        addObjectProperty(azure, propAdotaParadigma, p4);
        addObjectProperty(azure, propAdotaParadigma, p5);

        addObjectProperty(gcp, propAdotaParadigma, p1);
        addObjectProperty(gcp, propAdotaParadigma, p2);
        addObjectProperty(gcp, propAdotaParadigma, p3);
        addObjectProperty(gcp, propAdotaParadigma, p4);
        addObjectProperty(gcp, propAdotaParadigma, p5);
    }

    // ============================================================
    // QC4 - Serviços AWS
    // ============================================================
    private void createAWSServiceIndividuals() {
        OWLNamedIndividual aws = getIndividual("Plataforma_AWS");

        // Serviços fundamentais (2006)
        OWLNamedIndividual ec2 = createIndividual("AWS_EC2", classAmazonEC2);
        addDataProperty(ec2, dphHasName, "Amazon EC2");
        addDataProperty(ec2, dphHasDescription, "Serviço de computação escalável sob demanda. Permite provisionar máquinas virtuais com diferentes configurações.");
        addDataProperty(ec2, dphHasLaunchYear, "2006");
        addDataProperty(ec2, dphHasServiceType, "Computação");
        addDataProperty(ec2, dphHasReference, "Arruda et al., 2025");
        addDataProperty(ec2, dphHasTag, "amazon-ec2");

        OWLNamedIndividual s3 = createIndividual("AWS_S3", classAmazonS3);
        addDataProperty(s3, dphHasName, "Amazon S3");
        addDataProperty(s3, dphHasDescription, "Armazenamento de objetos em larga escala. Permite armazenar e recuperar dados de qualquer lugar.");
        addDataProperty(s3, dphHasLaunchYear, "2006");
        addDataProperty(s3, dphHasServiceType, "Armazenamento");
        addDataProperty(s3, dphHasReference, "Arruda et al., 2025");
        addDataProperty(s3, dphHasTag, "amazon-s3");

        // Serviços gerenciados (2012-2014)
        OWLNamedIndividual dynamodb = createIndividual("AWS_DynamoDB", classAmazonDynamoDB);
        addDataProperty(dynamodb, dphHasName, "Amazon DynamoDB");
        addDataProperty(dynamodb, dphHasDescription, "Banco de dados NoSQL gerenciado, com baixa latência e escalabilidade automática.");
        addDataProperty(dynamodb, dphHasLaunchYear, "2012");
        addDataProperty(dynamodb, dphHasServiceType, "Banco de Dados");
        addDataProperty(dynamodb, dphHasReference, "Arruda et al., 2025");
        addDataProperty(dynamodb, dphHasTag, "amazon-dynamodb");

        OWLNamedIndividual elasticBeanstalk = createIndividual("AWS_ElasticBeanstalk", classAmazonElasticBeanstalk);
        addDataProperty(elasticBeanstalk, dphHasName, "Amazon Elastic Beanstalk");
        addDataProperty(elasticBeanstalk, dphHasDescription, "Serviço de PaaS para implantação automática de aplicações web.");
        addDataProperty(elasticBeanstalk, dphHasLaunchYear, "2011");
        addDataProperty(elasticBeanstalk, dphHasServiceType, "PaaS");
        addDataProperty(elasticBeanstalk, dphHasReference, "Arruda et al., 2025");
        addDataProperty(elasticBeanstalk, dphHasTag, "elastic-beanstalk");

        // Serverless (2014)
        OWLNamedIndividual lambda = createIndividual("AWS_Lambda", classAWSLambda);
        addDataProperty(lambda, dphHasName, "AWS Lambda");
        addDataProperty(lambda, dphHasDescription, "Computação serverless. Executa código sob demanda sem provisionamento de servidores.");
        addDataProperty(lambda, dphHasLaunchYear, "2014");
        addDataProperty(lambda, dphHasServiceType, "Serverless");
        addDataProperty(lambda, dphHasReference, "Arruda et al., 2025");
        addDataProperty(lambda, dphHasTag, "aws-lambda");
        addDataProperty(lambda, dphHasAdoptionLevel, "Alta");

        // Autenticação (2014)
        OWLNamedIndividual cognito = createIndividual("AWS_Cognito", classAWSCognito);
        addDataProperty(cognito, dphHasName, "Amazon Cognito");
        addDataProperty(cognito, dphHasDescription, "Serviço de autenticação e gerenciamento de usuários para aplicações web e móveis.");
        addDataProperty(cognito, dphHasLaunchYear, "2014");
        addDataProperty(cognito, dphHasServiceType, "Autenticação");
        addDataProperty(cognito, dphHasReference, "Arruda et al., 2025");
        addDataProperty(cognito, dphHasTag, "amazon-cognito");

        // API Gateway (2015)
        OWLNamedIndividual apiGateway = createIndividual("AWS_APIGateway", classAmazonAPIGateway);
        addDataProperty(apiGateway, dphHasName, "Amazon API Gateway");
        addDataProperty(apiGateway, dphHasDescription, "Serviço para criar, publicar e gerenciar APIs RESTful e WebSocket.");
        addDataProperty(apiGateway, dphHasLaunchYear, "2015");
        addDataProperty(apiGateway, dphHasServiceType, "API");
        addDataProperty(apiGateway, dphHasReference, "Arruda et al., 2025");
        addDataProperty(apiGateway, dphHasTag, "aws-api-gateway");

        // Dados e ETL (2017)
        OWLNamedIndividual glue = createIndividual("AWS_Glue", classAWSGlue);
        addDataProperty(glue, dphHasName, "AWS Glue");
        addDataProperty(glue, dphHasDescription, "Serviço de ETL e integração de dados. Prepara dados para análise e machine learning.");
        addDataProperty(glue, dphHasLaunchYear, "2017");
        addDataProperty(glue, dphHasServiceType, "Dados");
        addDataProperty(glue, dphHasReference, "Arruda et al., 2025");
        addDataProperty(glue, dphHasTag, "aws-glue");

        // Desenvolvimento (2017)
        OWLNamedIndividual amplify = createIndividual("AWS_Amplify", classAWSAmplify);
        addDataProperty(amplify, dphHasName, "AWS Amplify");
        addDataProperty(amplify, dphHasDescription, "Plataforma para desenvolvimento fullstack de aplicações web e móveis.");
        addDataProperty(amplify, dphHasLaunchYear, "2017");
        addDataProperty(amplify, dphHasServiceType, "Desenvolvimento");
        addDataProperty(amplify, dphHasReference, "Arruda et al., 2025");
        addDataProperty(amplify, dphHasTag, "aws-amplify");

        // Infraestrutura como Código
        OWLNamedIndividual terraform = createIndividual("AWS_Terraform", classTerraform);
        addDataProperty(terraform, dphHasName, "Terraform");
        addDataProperty(terraform, dphHasDescription, "Ferramenta de infraestrutura como código. Permite definir recursos de nuvem de forma declarativa.");
        addDataProperty(terraform, dphHasLaunchYear, "2014");
        addDataProperty(terraform, dphHasServiceType, "Infraestrutura como Código");
        addDataProperty(terraform, dphHasReference, "Arruda et al., 2025");
        addDataProperty(terraform, dphHasTag, "terraform");

        // IA Generativa (2023)
        OWLNamedIndividual bedrock = createIndividual("AWS_Bedrock", classAmazonBedrock);
        addDataProperty(bedrock, dphHasName, "Amazon Bedrock");
        addDataProperty(bedrock, dphHasDescription, "Serviço de IA generativa para foundation models. Permite construir aplicações com LLMs.");
        addDataProperty(bedrock, dphHasLaunchYear, "2023");
        addDataProperty(bedrock, dphHasServiceType, "IA Generativa");
        addDataProperty(bedrock, dphHasReference, "Arruda et al., 2025");
        addDataProperty(bedrock, dphHasTag, "amazon-bedrock");

        // Adiciona serviços à AWS
        if (aws != null) {
            addObjectProperty(aws, propOfereceServico, ec2);
            addObjectProperty(aws, propOfereceServico, s3);
            addObjectProperty(aws, propOfereceServico, dynamodb);
            addObjectProperty(aws, propOfereceServico, elasticBeanstalk);
            addObjectProperty(aws, propOfereceServico, lambda);
            addObjectProperty(aws, propOfereceServico, cognito);
            addObjectProperty(aws, propOfereceServico, apiGateway);
            addObjectProperty(aws, propOfereceServico, glue);
            addObjectProperty(aws, propOfereceServico, amplify);
            addObjectProperty(aws, propOfereceServico, terraform);
            addObjectProperty(aws, propOfereceServico, bedrock);
        }
    }

    // ============================================================
    // QC5 - Serviços Azure
    // ============================================================
    private void createAzureServiceIndividuals() {
        OWLNamedIndividual azure = getIndividual("Plataforma_Azure");

        // Serviços iniciais (2010-2012)
        OWLNamedIndividual storage = createIndividual("Azure_Storage", classAzureStorage);
        addDataProperty(storage, dphHasName, "Azure Storage");
        addDataProperty(storage, dphHasDescription, "Serviço de armazenamento de dados em nuvem (blobs, filas, tabelas, arquivos).");
        addDataProperty(storage, dphHasLaunchYear, "2010");
        addDataProperty(storage, dphHasServiceType, "Armazenamento");
        addDataProperty(storage, dphHasReference, "Arruda et al., 2025");
        addDataProperty(storage, dphHasTag, "azure-storage");

        OWLNamedIndividual activeDirectory = createIndividual("Azure_ActiveDirectory", classAzureActiveDirectory);
        addDataProperty(activeDirectory, dphHasName, "Azure Active Directory");
        addDataProperty(activeDirectory, dphHasDescription, "Serviço de identidade e autenticação. Gerencia usuários e acessos.");
        addDataProperty(activeDirectory, dphHasLaunchYear, "2010");
        addDataProperty(activeDirectory, dphHasServiceType, "Autenticação");
        addDataProperty(activeDirectory, dphHasReference, "Arruda et al., 2025");
        addDataProperty(activeDirectory, dphHasTag, "azure-active-directory");

        OWLNamedIndividual sqlDatabase = createIndividual("Azure_SQLDatabase", classAzureSQLDatabase);
        addDataProperty(sqlDatabase, dphHasName, "Azure SQL Database");
        addDataProperty(sqlDatabase, dphHasDescription, "Banco de dados relacional gerenciado baseado em SQL Server.");
        addDataProperty(sqlDatabase, dphHasLaunchYear, "2010");
        addDataProperty(sqlDatabase, dphHasServiceType, "Banco de Dados");
        addDataProperty(sqlDatabase, dphHasReference, "Arruda et al., 2025");
        addDataProperty(sqlDatabase, dphHasTag, "azure-sql-database");

        // Mobile Services (2012)
        OWLNamedIndividual mobileServices = createIndividual("Azure_MobileServices", classAzureMobileServices);
        addDataProperty(mobileServices, dphHasName, "Azure Mobile Services");
        addDataProperty(mobileServices, dphHasDescription, "Backend para aplicações móveis com autenticação e notificações.");
        addDataProperty(mobileServices, dphHasLaunchYear, "2012");
        addDataProperty(mobileServices, dphHasServiceType, "Mobile");
        addDataProperty(mobileServices, dphHasReference, "Arruda et al., 2025");
        addDataProperty(mobileServices, dphHasTag, "azure-mobile-services");

        // Web App Service (2013)
        OWLNamedIndividual webAppService = createIndividual("Azure_WebAppService", classAzureWebAppService);
        addDataProperty(webAppService, dphHasName, "Azure Web App Service");
        addDataProperty(webAppService, dphHasDescription, "Serviço de hospedagem gerenciada para aplicações web.");
        addDataProperty(webAppService, dphHasLaunchYear, "2013");
        addDataProperty(webAppService, dphHasServiceType, "PaaS");
        addDataProperty(webAppService, dphHasReference, "Arruda et al., 2025");
        addDataProperty(webAppService, dphHasTag, "azure-web-app-service");

        // DevOps (2013)
        OWLNamedIndividual devops = createIndividual("Azure_DevOps", classAzureDevOps);
        addDataProperty(devops, dphHasName, "Azure DevOps");
        addDataProperty(devops, dphHasDescription, "Suite de ferramentas para CI/CD, versionamento e gerenciamento de projetos.");
        addDataProperty(devops, dphHasLaunchYear, "2013");
        addDataProperty(devops, dphHasServiceType, "DevOps");
        addDataProperty(devops, dphHasReference, "Arruda et al., 2025");
        addDataProperty(devops, dphHasTag, "azure-devops");
        addDataProperty(devops, dphHasAdoptionLevel, "Alta");

        // Data Factory (2015)
        OWLNamedIndividual dataFactory = createIndividual("Azure_DataFactory", classAzureDataFactory);
        addDataProperty(dataFactory, dphHasName, "Azure Data Factory");
        addDataProperty(dataFactory, dphHasDescription, "Serviço de integração e transformação de dados (ETL/ELT).");
        addDataProperty(dataFactory, dphHasLaunchYear, "2015");
        addDataProperty(dataFactory, dphHasServiceType, "Dados");
        addDataProperty(dataFactory, dphHasReference, "Arruda et al., 2025");
        addDataProperty(dataFactory, dphHasTag, "azure-data-factory");

        // Cosmos DB (2015)
        OWLNamedIndividual cosmosDB = createIndividual("Azure_CosmosDB", classAzureCosmosDB);
        addDataProperty(cosmosDB, dphHasName, "Azure Cosmos DB");
        addDataProperty(cosmosDB, dphHasDescription, "Banco de dados NoSQL multimodelo, globalmente distribuído e altamente escalável.");
        addDataProperty(cosmosDB, dphHasLaunchYear, "2015");
        addDataProperty(cosmosDB, dphHasServiceType, "Banco de Dados");
        addDataProperty(cosmosDB, dphHasReference, "Arruda et al., 2025");
        addDataProperty(cosmosDB, dphHasTag, "azure-cosmosdb");

        // Serverless (2016)
        OWLNamedIndividual functions = createIndividual("Azure_Functions", classAzureFunctions);
        addDataProperty(functions, dphHasName, "Azure Functions");
        addDataProperty(functions, dphHasDescription, "Computação serverless sob demanda. Executa código em resposta a eventos.");
        addDataProperty(functions, dphHasLaunchYear, "2016");
        addDataProperty(functions, dphHasServiceType, "Serverless");
        addDataProperty(functions, dphHasReference, "Arruda et al., 2025");
        addDataProperty(functions, dphHasTag, "azure-functions");

        // Pipelines (2015)
        OWLNamedIndividual pipelines = createIndividual("Azure_Pipelines", classAzurePipelines);
        addDataProperty(pipelines, dphHasName, "Azure Pipelines");
        addDataProperty(pipelines, dphHasDescription, "Pipeline de CI/CD automatizado para build, teste e deploy.");
        addDataProperty(pipelines, dphHasLaunchYear, "2015");
        addDataProperty(pipelines, dphHasServiceType, "DevOps");
        addDataProperty(pipelines, dphHasReference, "Arruda et al., 2025");
        addDataProperty(pipelines, dphHasTag, "azure-pipelines");

        // AKS (2017)
        OWLNamedIndividual aks = createIndividual("Azure_AKS", classAzureAKS);
        addDataProperty(aks, dphHasName, "Azure Kubernetes Service");
        addDataProperty(aks, dphHasDescription, "Serviço gerenciado de Kubernetes para orquestração de contêineres.");
        addDataProperty(aks, dphHasLaunchYear, "2017");
        addDataProperty(aks, dphHasServiceType, "Contêineres");
        addDataProperty(aks, dphHasReference, "Arruda et al., 2025");
        addDataProperty(aks, dphHasTag, "azure-aks");

        // IA Generativa (2023)
        OWLNamedIndividual openai = createIndividual("Azure_OpenAI", classAzureOpenAI);
        addDataProperty(openai, dphHasName, "Azure OpenAI");
        addDataProperty(openai, dphHasDescription, "Serviço de IA generativa com modelos da OpenAI (GPT-4, etc.) na plataforma Azure.");
        addDataProperty(openai, dphHasLaunchYear, "2023");
        addDataProperty(openai, dphHasServiceType, "IA Generativa");
        addDataProperty(openai, dphHasReference, "Arruda et al., 2025");
        addDataProperty(openai, dphHasTag, "azure-openai");

        // Synapse Analytics
        OWLNamedIndividual synapse = createIndividual("Azure_SynapseAnalytics", classAzureSynapseAnalytics);
        addDataProperty(synapse, dphHasName, "Azure Synapse Analytics");
        addDataProperty(synapse, dphHasDescription, "Plataforma de análise de dados integrada para data warehousing e big data.");
        addDataProperty(synapse, dphHasLaunchYear, "2020");
        addDataProperty(synapse, dphHasServiceType, "Dados");
        addDataProperty(synapse, dphHasReference, "Arruda et al., 2025");
        addDataProperty(synapse, dphHasTag, "azure-synapse-analytics");

        if (azure != null) {
            addObjectProperty(azure, propOfereceServico, storage);
            addObjectProperty(azure, propOfereceServico, activeDirectory);
            addObjectProperty(azure, propOfereceServico, sqlDatabase);
            addObjectProperty(azure, propOfereceServico, mobileServices);
            addObjectProperty(azure, propOfereceServico, webAppService);
            addObjectProperty(azure, propOfereceServico, devops);
            addObjectProperty(azure, propOfereceServico, dataFactory);
            addObjectProperty(azure, propOfereceServico, cosmosDB);
            addObjectProperty(azure, propOfereceServico, functions);
            addObjectProperty(azure, propOfereceServico, pipelines);
            addObjectProperty(azure, propOfereceServico, aks);
            addObjectProperty(azure, propOfereceServico, openai);
            addObjectProperty(azure, propOfereceServico, synapse);
        }
    }

    // ============================================================
    // QC6 - Serviços GCP
    // ============================================================
    private void createGCPServiceIndividuals() {
        OWLNamedIndividual gcp = getIndividual("Plataforma_GCP");

        // App Engine (2008)
        OWLNamedIndividual appEngine = createIndividual("GCP_AppEngine", classGoogleAppEngine);
        addDataProperty(appEngine, dphHasName, "Google App Engine");
        addDataProperty(appEngine, dphHasDescription, "PaaS para hospedagem de aplicações web escaláveis. Suporte a Python, Java, Go.");
        addDataProperty(appEngine, dphHasLaunchYear, "2008");
        addDataProperty(appEngine, dphHasServiceType, "PaaS");
        addDataProperty(appEngine, dphHasReference, "Arruda et al., 2025");
        addDataProperty(appEngine, dphHasTag, "google-app-engine");

        // Datastore (2008)
        OWLNamedIndividual datastore = createIndividual("GCP_Datastore", classGoogleCloudDatastore);
        addDataProperty(datastore, dphHasName, "Google Cloud Datastore");
        addDataProperty(datastore, dphHasDescription, "Banco de dados NoSQL gerenciado para aplicações web (legado).");
        addDataProperty(datastore, dphHasLaunchYear, "2008");
        addDataProperty(datastore, dphHasServiceType, "Banco de Dados");
        addDataProperty(datastore, dphHasReference, "Arruda et al., 2025");
        addDataProperty(datastore, dphHasTag, "google-cloud-datastore");

        // Cloud Storage
        OWLNamedIndividual storage = createIndividual("GCP_Storage", classGoogleCloudStorage);
        addDataProperty(storage, dphHasName, "Google Cloud Storage");
        addDataProperty(storage, dphHasDescription, "Armazenamento de objetos em larga escala com alta durabilidade.");
        addDataProperty(storage, dphHasLaunchYear, "2010");
        addDataProperty(storage, dphHasServiceType, "Armazenamento");
        addDataProperty(storage, dphHasReference, "Arruda et al., 2025");
        addDataProperty(storage, dphHasTag, "google-cloud-storage");

        // Cloud SQL
        OWLNamedIndividual sql = createIndividual("GCP_SQL", classGoogleCloudSQL);
        addDataProperty(sql, dphHasName, "Google Cloud SQL");
        addDataProperty(sql, dphHasDescription, "Banco de dados relacional gerenciado (MySQL, PostgreSQL, SQL Server).");
        addDataProperty(sql, dphHasLaunchYear, "2010");
        addDataProperty(sql, dphHasServiceType, "Banco de Dados");
        addDataProperty(sql, dphHasReference, "Arruda et al., 2025");
        addDataProperty(sql, dphHasTag, "google-cloud-sql");

        // Firebase (2014)
        OWLNamedIndividual firebase = createIndividual("GCP_Firebase", classFirebase);
        addDataProperty(firebase, dphHasName, "Firebase");
        addDataProperty(firebase, dphHasDescription, "Plataforma para desenvolvimento móvel e web. Inclui autenticação, banco de dados em tempo real, hosting.");
        addDataProperty(firebase, dphHasLaunchYear, "2014");
        addDataProperty(firebase, dphHasServiceType, "Desenvolvimento");
        addDataProperty(firebase, dphHasReference, "Arruda et al., 2025");
        addDataProperty(firebase, dphHasTag, "firebase");
        addDataProperty(firebase, dphHasAdoptionLevel, "Alta");

        // Cloud Messaging (2012)
        OWLNamedIndividual messaging = createIndividual("GCP_Messaging", classGoogleCloudMessaging);
        addDataProperty(messaging, dphHasName, "Google Cloud Messaging");
        addDataProperty(messaging, dphHasDescription, "Serviço de notificações push para aplicações móveis.");
        addDataProperty(messaging, dphHasLaunchYear, "2012");
        addDataProperty(messaging, dphHasServiceType, "Notificações");
        addDataProperty(messaging, dphHasReference, "Arruda et al., 2025");
        addDataProperty(messaging, dphHasTag, "google-cloud-messaging");

        // Cloud Functions (2016)
        OWLNamedIndividual cloudFunctions = createIndividual("GCP_CloudFunctions", classGoogleCloudFunctions);
        addDataProperty(cloudFunctions, dphHasName, "Google Cloud Functions");
        addDataProperty(cloudFunctions, dphHasDescription, "Computação serverless event-driven. Executa código em resposta a eventos.");
        addDataProperty(cloudFunctions, dphHasLaunchYear, "2016");
        addDataProperty(cloudFunctions, dphHasServiceType, "Serverless");
        addDataProperty(cloudFunctions, dphHasReference, "Arruda et al., 2025");
        addDataProperty(cloudFunctions, dphHasTag, "google-cloud-functions");

        // Apache Beam (2016)
        OWLNamedIndividual beam = createIndividual("GCP_Beam", classApacheBeam);
        addDataProperty(beam, dphHasName, "Apache Beam");
        addDataProperty(beam, dphHasDescription, "Pipeline de processamento de dados em lote e streaming (Dataflow).");
        addDataProperty(beam, dphHasLaunchYear, "2016");
        addDataProperty(beam, dphHasServiceType, "Dados");
        addDataProperty(beam, dphHasReference, "Arruda et al., 2025");
        addDataProperty(beam, dphHasTag, "beam");

        // Flutter (2017)
        OWLNamedIndividual flutter = createIndividual("GCP_Flutter", classFlutter);
        addDataProperty(flutter, dphHasName, "Flutter");
        addDataProperty(flutter, dphHasDescription, "Framework para aplicações multiplataforma (iOS, Android, Web, Desktop).");
        addDataProperty(flutter, dphHasLaunchYear, "2017");
        addDataProperty(flutter, dphHasServiceType, "Desenvolvimento");
        addDataProperty(flutter, dphHasReference, "Arruda et al., 2025");
        addDataProperty(flutter, dphHasTag, "flutter");

        // Firestore (2017)
        OWLNamedIndividual firestore = createIndividual("GCP_Firestore", classGoogleCloudFirestore);
        addDataProperty(firestore, dphHasName, "Google Cloud Firestore");
        addDataProperty(firestore, dphHasDescription, "Banco de dados NoSQL em tempo real, escalável e com sincronização automática.");
        addDataProperty(firestore, dphHasLaunchYear, "2017");
        addDataProperty(firestore, dphHasServiceType, "Banco de Dados");
        addDataProperty(firestore, dphHasReference, "Arruda et al., 2025");
        addDataProperty(firestore, dphHasTag, "google-cloud-firestore");
        addDataProperty(firestore, dphHasAdoptionLevel, "Alta");

        // DataProc (2015)
        OWLNamedIndividual dataproc = createIndividual("GCP_DataProc", classGoogleCloudDataProc);
        addDataProperty(dataproc, dphHasName, "Google Cloud DataProc");
        addDataProperty(dataproc, dphHasDescription, "Serviço gerenciado para processamento de dados com Hadoop e Spark.");
        addDataProperty(dataproc, dphHasLaunchYear, "2015");
        addDataProperty(dataproc, dphHasServiceType, "Dados");
        addDataProperty(dataproc, dphHasReference, "Arruda et al., 2025");
        addDataProperty(dataproc, dphHasTag, "google-cloud-dataproc");

        // Kubernetes (2014)
        OWLNamedIndividual kubernetes = createIndividual("GCP_Kubernetes", classKubernetes);
        addDataProperty(kubernetes, dphHasName, "Kubernetes");
        addDataProperty(kubernetes, dphHasDescription, "Orquestrador de contêineres open-source, criado pelo Google.");
        addDataProperty(kubernetes, dphHasLaunchYear, "2014");
        addDataProperty(kubernetes, dphHasServiceType, "Contêineres");
        addDataProperty(kubernetes, dphHasReference, "Arruda et al., 2025");
        addDataProperty(kubernetes, dphHasTag, "kubernetes");

        // Vertex AI (2021)
        OWLNamedIndividual vertexAI = createIndividual("GCP_VertexAI", classGoogleCloudVertexAI);
        addDataProperty(vertexAI, dphHasName, "Google Cloud Vertex AI");
        addDataProperty(vertexAI, dphHasDescription, "Plataforma unificada de IA e machine learning para treino, deploy e monitoramento.");
        addDataProperty(vertexAI, dphHasLaunchYear, "2021");
        addDataProperty(vertexAI, dphHasServiceType, "IA/ML");
        addDataProperty(vertexAI, dphHasReference, "Arruda et al., 2025");
        addDataProperty(vertexAI, dphHasTag, "google-cloud-vertex-ai");

        // Gemini (2023)
        OWLNamedIndividual gemini = createIndividual("GCP_Gemini", classGoogleGemini);
        addDataProperty(gemini, dphHasName, "Google Gemini");
        addDataProperty(gemini, dphHasDescription, "Modelo de IA generativa multimodal do Google.");
        addDataProperty(gemini, dphHasLaunchYear, "2023");
        addDataProperty(gemini, dphHasServiceType, "IA Generativa");
        addDataProperty(gemini, dphHasReference, "Arruda et al., 2025");
        addDataProperty(gemini, dphHasTag, "google-gemini");

        // LangChain
        OWLNamedIndividual langchain = createIndividual("GCP_LangChain", classLangChain);
        addDataProperty(langchain, dphHasName, "LangChain");
        addDataProperty(langchain, dphHasDescription, "Framework para desenvolvimento de aplicações com LLMs (Large Language Models).");
        addDataProperty(langchain, dphHasLaunchYear, "2022");
        addDataProperty(langchain, dphHasServiceType, "IA Generativa");
        addDataProperty(langchain, dphHasReference, "Arruda et al., 2025");
        addDataProperty(langchain, dphHasTag, "langchain");

        if (gcp != null) {
            addObjectProperty(gcp, propOfereceServico, appEngine);
            addObjectProperty(gcp, propOfereceServico, datastore);
            addObjectProperty(gcp, propOfereceServico, storage);
            addObjectProperty(gcp, propOfereceServico, sql);
            addObjectProperty(gcp, propOfereceServico, firebase);
            addObjectProperty(gcp, propOfereceServico, messaging);
            addObjectProperty(gcp, propOfereceServico, cloudFunctions);
            addObjectProperty(gcp, propOfereceServico, beam);
            addObjectProperty(gcp, propOfereceServico, flutter);
            addObjectProperty(gcp, propOfereceServico, firestore);
            addObjectProperty(gcp, propOfereceServico, dataproc);
            addObjectProperty(gcp, propOfereceServico, kubernetes);
            addObjectProperty(gcp, propOfereceServico, vertexAI);
            addObjectProperty(gcp, propOfereceServico, gemini);
            addObjectProperty(gcp, propOfereceServico, langchain);
        }
    }

    // ============================================================
    // QC7 - Comunidades de Desenvolvedores
    // ============================================================
    private void createCommunityIndividuals() {
        OWLNamedIndividual stackOverflow = createIndividual("Comunidade_StackOverflow", classStackOverflow);
        addDataProperty(stackOverflow, dphHasName, "Stack Overflow");
        addDataProperty(stackOverflow, dphHasDescription, "Fórum de perguntas e respostas para desenvolvedores. Funciona como repositório vivo da evolução de ecossistemas de nuvem.");
        addDataProperty(stackOverflow, dphHasReference, "Barua et al., 2014; Fontão et al., 2018; Arruda et al., 2025");
        addDataProperty(stackOverflow, dphHasStudyCount, "Milhões de interações (2008-2025)");
        addDataProperty(stackOverflow, dphHasPeriodo, "2008-2025");

        // Conecta comunidades às plataformas
        OWLNamedIndividual aws = getIndividual("Plataforma_AWS");
        OWLNamedIndividual azure = getIndividual("Plataforma_Azure");
        OWLNamedIndividual gcp = getIndividual("Plataforma_GCP");

        if (aws != null) {
            addObjectProperty(aws, propPossuiComunidade, stackOverflow);
        }
        if (azure != null) {
            addObjectProperty(azure, propPossuiComunidade, stackOverflow);
        }
        if (gcp != null) {
            addObjectProperty(gcp, propPossuiComunidade, stackOverflow);
        }
    }

    // ============================================================
    // QC8 - Fatores de Evolução
    // ============================================================
    private void createFatoresEvolucao() {
        // Fatores de Evolução como indivíduos
        OWLNamedIndividual f1 = createIndividual("Fator_AvançosTecnologicos", classAtor);
        addDataProperty(f1, dphHasName, "Avanços Tecnológicos");
        addDataProperty(f1, dphHasDescription, "Novos serviços e paradigmas (serverless, contêineres, IA) impulsionam a evolução.");
        addDataProperty(f1, dphHasReference, "Arruda et al., 2025");
        addDataProperty(f1, dphHasCategory, "Fator de Evolução");

        OWLNamedIndividual f2 = createIndividual("Fator_DemandasMercado", classAtor);
        addDataProperty(f2, dphHasName, "Demandas do Mercado");
        addDataProperty(f2, dphHasDescription, "Necessidades de escalabilidade, segurança e inovação orientam o desenvolvimento.");
        addDataProperty(f2, dphHasReference, "Arruda et al., 2025");
        addDataProperty(f2, dphHasCategory, "Fator de Evolução");

        OWLNamedIndividual f3 = createIndividual("Fator_Comunidades", classAtor);
        addDataProperty(f3, dphHasName, "Comunidades de Desenvolvedores");
        addDataProperty(f3, dphHasDescription, "Adoção, feedback e contribuição das comunidades influenciam a evolução.");
        addDataProperty(f3, dphHasReference, "Arruda et al., 2025");
        addDataProperty(f3, dphHasCategory, "Fator de Evolução");

        OWLNamedIndividual f4 = createIndividual("Fator_PressoesRegulatorias", classAtor);
        addDataProperty(f4, dphHasName, "Pressões Regulatórias");
        addDataProperty(f4, dphHasDescription, "Conformidade e governança de dados (GDPR, LGPD) moldam as plataformas.");
        addDataProperty(f4, dphHasReference, "Arruda et al., 2025");
        addDataProperty(f4, dphHasCategory, "Fator de Evolução");

        OWLNamedIndividual f5 = createIndividual("Fator_EstrategiasProvedores", classAtor);
        addDataProperty(f5, dphHasName, "Estratégias dos Provedores");
        addDataProperty(f5, dphHasDescription, "Posicionamento e diferenciação competitiva (AWS pioneirismo, Azure corporativo, GCP dados).");
        addDataProperty(f5, dphHasReference, "Arruda et al., 2025");
        addDataProperty(f5, dphHasCategory, "Fator de Evolução");
    }

    // ============================================================
    // QC9 - Governança
    // ============================================================
    private void createGovernancaIndividuals() {
        OWLNamedIndividual contratoTecnico = createIndividual("Governanca_ContratoTecnico", classContratoTecnico);
        addDataProperty(contratoTecnico, dphHasName, "Contratos Técnicos");
        addDataProperty(contratoTecnico, dphHasDescription, "Padrões de API e Acordos de Nível de Serviço (SLA) que definem a interação entre componentes.");
        addDataProperty(contratoTecnico, dphHasReference, "Wareham et al., 2014");

        OWLNamedIndividual contratoComercial = createIndividual("Governanca_ContratoComercial", classContratoComercial);
        addDataProperty(contratoComercial, dphHasName, "Contratos Comerciais");
        addDataProperty(contratoComercial, dphHasDescription, "Modelos de precificação e licenciamento que regem as relações comerciais.");
        addDataProperty(contratoComercial, dphHasReference, "Wareham et al., 2014");

        OWLNamedIndividual api = createIndividual("Governanca_API", classAPI);
        addDataProperty(api, dphHasName, "APIs");
        addDataProperty(api, dphHasDescription, "Interfaces de programação que permitem a integração entre serviços e aplicações.");
        addDataProperty(api, dphHasReference, "Wareham et al., 2014");

        OWLNamedIndividual sla = createIndividual("Governanca_SLA", classSLA);
        addDataProperty(sla, dphHasName, "Acordos de Nível de Serviço (SLA)");
        addDataProperty(sla, dphHasDescription, "Garantias de disponibilidade, desempenho e suporte oferecidas pelos provedores.");
        addDataProperty(sla, dphHasReference, "Wareham et al., 2014");

        // Conecta governança às plataformas
        OWLNamedIndividual aws = getIndividual("Plataforma_AWS");
        OWLNamedIndividual azure = getIndividual("Plataforma_Azure");
        OWLNamedIndividual gcp = getIndividual("Plataforma_GCP");

        if (aws != null) {
            addObjectProperty(aws, propPossuiGovernanca, contratoTecnico);
            addObjectProperty(aws, propPossuiGovernanca, contratoComercial);
            addObjectProperty(aws, propPossuiGovernanca, api);
            addObjectProperty(aws, propPossuiGovernanca, sla);
        }
        if (azure != null) {
            addObjectProperty(azure, propPossuiGovernanca, contratoTecnico);
            addObjectProperty(azure, propPossuiGovernanca, contratoComercial);
            addObjectProperty(azure, propPossuiGovernanca, api);
            addObjectProperty(azure, propPossuiGovernanca, sla);
        }
        if (gcp != null) {
            addObjectProperty(gcp, propPossuiGovernanca, contratoTecnico);
            addObjectProperty(gcp, propPossuiGovernanca, contratoComercial);
            addObjectProperty(gcp, propPossuiGovernanca, api);
            addObjectProperty(gcp, propPossuiGovernanca, sla);
        }
    }

    // ============================================================
    // QC10 - Diferenças Evolutivas (já parcialmente coberto)
    // ============================================================
    private void createDiferencasEvolutivas() {
        // As diferenças já estão nas propriedades das plataformas
        // Complementar com tags específicas
        OWLNamedIndividual aws = getIndividual("Plataforma_AWS");
        OWLNamedIndividual azure = getIndividual("Plataforma_Azure");
        OWLNamedIndividual gcp = getIndividual("Plataforma_GCP");

        if (aws != null) {
            addDataProperty(aws, dphHasTag, "Pioneira, generalista, forte em serverless e IaaS");
        }
        if (azure != null) {
            addDataProperty(azure, dphHasTag, "Corporativa, integração .NET, DevOps e identidade");
        }
        if (gcp != null) {
            addDataProperty(gcp, dphHasTag, "Dados e IA, Firebase, engenharia de dados");
        }
    }

    // ============================================================
    // QC11 - IA Generativa
    // ============================================================
    private void createIAGenerativaImpacto() {
        OWLNamedIndividual iaGen = getIndividual("Paradigma_IAGenerativa");
        if (iaGen == null) return;

        // Serviços de IA Generativa
        OWLNamedIndividual bedrock = getIndividual("AWS_Bedrock");
        OWLNamedIndividual openai = getIndividual("Azure_OpenAI");
        OWLNamedIndividual gemini = getIndividual("GCP_Gemini");
        OWLNamedIndividual langchain = getIndividual("GCP_LangChain");

        if (bedrock != null) addObjectProperty(iaGen, propInfluencia, bedrock);
        if (openai != null) addObjectProperty(iaGen, propInfluencia, openai);
        if (gemini != null) addObjectProperty(iaGen, propInfluencia, gemini);
        if (langchain != null) addObjectProperty(iaGen, propInfluencia, langchain);

        // Tags emergentes de IA Generativa
        addDataProperty(iaGen, dphHasTag, "amazon-bedrock, azure-openai, google-gemini, langchain, large-language-model");
        addDataProperty(iaGen, dphHasImpacto, "Preocupações: latência, governança de modelos, RAG, copilots");
    }

    // ============================================================
    // QC12 - Métodos de Análise
    // ============================================================
    private void createMetodoIndividuals() {
        OWLNamedIndividual lda = createIndividual("Metodo_LDA", classLDA);
        addDataProperty(lda, dphHasName, "Latent Dirichlet Allocation (LDA)");
        addDataProperty(lda, dphHasDescription, "Algoritmo para modelagem de tópicos. Identifica padrões temáticos em grandes conjuntos de textos.");
        addDataProperty(lda, dphHasReference, "Blei, Ng e Jordan, 2003");
        addDataProperty(lda, dphHasTag, "4 tópicos por período, max_iter=20");

        OWLNamedIndividual mineracao = createIndividual("Metodo_MineracaoDados", classMineraçãoDados);
        addDataProperty(mineracao, dphHasName, "Mineração de Dados");
        addDataProperty(mineracao, dphHasDescription, "Extração de dados de repositórios de perguntas e respostas (Stack Overflow).");
        addDataProperty(mineracao, dphHasReference, "Arruda et al., 2025");
        addDataProperty(mineracao, dphHasTag, "Fonte: Stack Exchange Data Dump (2008-2025)");

        OWLNamedIndividual tendencias = createIndividual("Metodo_AnaliseTendencias", classAnaliseTendencias);
        addDataProperty(tendencias, dphHasName, "Análise de Tendências Contextuais");
        addDataProperty(tendencias, dphHasDescription, "Segmentação temporal em janelas de análise (5 períodos: 2008-2012, 2013-2016, 2017-2019, 2020-2022, 2023-2025).");
        addDataProperty(tendencias, dphHasReference, "Arruda et al., 2025");

        OWLNamedIndividual tags = createIndividual("Metodo_AnaliseTags", classAnaliseTags);
        addDataProperty(tags, dphHasName, "Análise de Tags");
        addDataProperty(tags, dphHasDescription, "Identificação de serviços centrais e tecnologias emergentes via Top 10 tags por período.");
        addDataProperty(tags, dphHasReference, "Arruda et al., 2025");

        OWLNamedIndividual gqm = createIndividual("Metodo_GQM", classGQM);
        addDataProperty(gqm, dphHasName, "Goal-Question-Metric (GQM)");
        addDataProperty(gqm, dphHasDescription, "Abordagem para estruturação de pesquisa com metas analíticas, questões de pesquisa e métricas.");
        addDataProperty(gqm, dphHasReference, "Fontão et al., 2018; Arruda et al., 2025");

        // Conecta métodos à análise
        OWLNamedIndividual ecossistema = getIndividual("Ecossistema_Cloud");
        if (ecossistema != null) {
            addObjectProperty(ecossistema, propUtilizaMetodo, lda);
            addObjectProperty(ecossistema, propUtilizaMetodo, mineracao);
            addObjectProperty(ecossistema, propUtilizaMetodo, tendencias);
            addObjectProperty(ecossistema, propUtilizaMetodo, tags);
            addObjectProperty(ecossistema, propUtilizaMetodo, gqm);
        }
    }

    // ============================================================
    // RELACIONAMENTOS ADICIONAIS
    // ============================================================
    private void createRelationships() {
        // Relacionamentos de influência - paradigmas influenciam serviços
        OWLNamedIndividual lambda = getIndividual("AWS_Lambda");
        OWLNamedIndividual functions = getIndividual("Azure_Functions");
        OWLNamedIndividual cloudFunctions = getIndividual("GCP_CloudFunctions");

        OWLNamedIndividual serverless = getIndividual("Paradigma_ContainersServerless");
        
        if (serverless != null) {
            if (lambda != null) addObjectProperty(serverless, propInfluencia, lambda);
            if (functions != null) addObjectProperty(serverless, propInfluencia, functions);
            if (cloudFunctions != null) addObjectProperty(serverless, propInfluencia, cloudFunctions);
        }

        // IA Generativa influencia serviços
        OWLNamedIndividual bedrock = getIndividual("AWS_Bedrock");
        OWLNamedIndividual openai = getIndividual("Azure_OpenAI");
        OWLNamedIndividual gemini = getIndividual("GCP_Gemini");
        OWLNamedIndividual iaGen = getIndividual("Paradigma_IAGenerativa");

        if (iaGen != null) {
            if (bedrock != null) addObjectProperty(iaGen, propInfluencia, bedrock);
            if (openai != null) addObjectProperty(iaGen, propInfluencia, openai);
            if (gemini != null) addObjectProperty(iaGen, propInfluencia, gemini);
        }

        // Métodos de análise documentados no Stack Overflow
        OWLNamedIndividual stackOverflow = getIndividual("Comunidade_StackOverflow");
        OWLNamedIndividual lda = getIndividual("Metodo_LDA");
        if (stackOverflow != null && lda != null) {
            addObjectProperty(stackOverflow, propDocumentadoEm, lda);
        }
    }

    private void addAxioms() {
        // Restrições para garantir consistência
        OWLClassExpression platformRestriction1 = factory.getOWLObjectSomeValuesFrom(propOfereceServico, classServicoAWS);
        addSubClassAxiom(classPlataformaNuvem, platformRestriction1);

        OWLClassExpression platformRestriction2 = factory.getOWLObjectSomeValuesFrom(propAdotaParadigma, classParadigmaTecnologico);
        addSubClassAxiom(classPlataformaNuvem, platformRestriction2);

        OWLClassExpression platformRestriction3 = factory.getOWLObjectSomeValuesFrom(propPossuiModeloServico, classModeloServico);
        addSubClassAxiom(classPlataformaNuvem, platformRestriction3);

        OWLClassExpression ecosystemRestriction = factory.getOWLObjectSomeValuesFrom(propCoordena, classKeystone);
        addSubClassAxiom(classEcossistemaNuvem, ecosystemRestriction);
    }

    // ============================================================
    // MÉTODOS AUXILIARES
    // ============================================================
    private OWLClass createClass(String name) {
        OWLClass cls = factory.getOWLClass(IRI.create(NS + name));
        manager.addAxiom(ontology, factory.getOWLDeclarationAxiom(cls));
        return cls;
    }

    private void addSubClass(OWLClass sub, OWLClass sup) {
        manager.addAxiom(ontology, factory.getOWLSubClassOfAxiom(sub, sup));
    }

    private void addSubClassAxiom(OWLClass sub, OWLClassExpression sup) {
        manager.addAxiom(ontology, factory.getOWLSubClassOfAxiom(sub, sup));
    }

    private OWLObjectProperty createObjectProperty(String name) {
        OWLObjectProperty prop = factory.getOWLObjectProperty(IRI.create(NS + name));
        manager.addAxiom(ontology, factory.getOWLDeclarationAxiom(prop));
        return prop;
    }

    private OWLDataProperty createDataProperty(String name) {
        OWLDataProperty prop = factory.getOWLDataProperty(IRI.create(NS + name));
        manager.addAxiom(ontology, factory.getOWLDeclarationAxiom(prop));
        return prop;
    }

    private OWLNamedIndividual createIndividual(String name, OWLClass cls) {
        OWLNamedIndividual individual = factory.getOWLNamedIndividual(IRI.create(NS + name));
        manager.addAxiom(ontology, factory.getOWLDeclarationAxiom(individual));
        manager.addAxiom(ontology, factory.getOWLClassAssertionAxiom(cls, individual));
        return individual;
    }

    private OWLNamedIndividual getIndividual(String name) {
        return factory.getOWLNamedIndividual(IRI.create(NS + name));
    }

    private void addObjectProperty(OWLNamedIndividual subject, OWLObjectProperty prop, OWLNamedIndividual object) {
        if (subject != null && object != null) {
            manager.addAxiom(ontology, factory.getOWLObjectPropertyAssertionAxiom(prop, subject, object));
        }
    }

    private void addDataProperty(OWLNamedIndividual individual, OWLDataProperty prop, String value) {
        if (individual != null && value != null) {
            OWLLiteral literal = factory.getOWLLiteral(value);
            manager.addAxiom(ontology, factory.getOWLDataPropertyAssertionAxiom(prop, individual, literal));
        }
    }

    public void saveOntology(String outputDir, String format) {
        try {
            File dir = new File(outputDir);
            if (!dir.exists()) {
                dir.mkdirs();
            }

            String filePath;
            OWLDocumentFormat documentFormat;

            if ("rdf".equalsIgnoreCase(format) || "rdfxml".equalsIgnoreCase(format)) {
                filePath = outputDir + "/cloudeco-ontology.rdf";
                documentFormat = new RDFXMLDocumentFormat();
            } else {
                filePath = outputDir + "/cloudeco-ontology.owl";
                documentFormat = new RDFXMLDocumentFormat();
            }

            File file = new File(filePath);
            manager.saveOntology(ontology, documentFormat, IRI.create(file));

            System.out.println(ANSI_GREEN + "\n📁 Ontologia salva em: " + file.getAbsolutePath() + ANSI_RESET);
            System.out.println(ANSI_CYAN + "   Axiomas: " + ontology.getAxiomCount() + ANSI_RESET);
            System.out.println(ANSI_CYAN + "   Classes: " + ontology.getClassesInSignature().size() + ANSI_RESET);
            System.out.println(ANSI_CYAN + "   Indivíduos: " + ontology.getIndividualsInSignature().size() + ANSI_RESET);
            System.out.println(ANSI_CYAN + "   Propriedades de Objeto: " + ontology.getObjectPropertiesInSignature().size() + ANSI_RESET);
            System.out.println(ANSI_CYAN + "   Propriedades de Dados: " + ontology.getDataPropertiesInSignature().size() + ANSI_RESET);

        } catch (Exception e) {
            System.err.println("Erro ao salvar ontologia: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public void saveBothFormats(String outputDir) {
        saveOntology(outputDir, "rdf");
        saveOntology(outputDir, "owl");
    }

    // ============================================================
    // MAIN
    // ============================================================
    public static void main(String[] args) {
        System.out.println(ANSI_CYAN + "╔═══════════════════════════════════════════════════════════════════════════════╗" + ANSI_RESET);
        System.out.println(ANSI_CYAN + "║" + ANSI_BOLD + "  ☁️ CloudEco-Ontology v2.0 (Completa)" + ANSI_RESET + ANSI_CYAN + "                                          ║" + ANSI_RESET);
        System.out.println(ANSI_CYAN + "║  📚 Baseado no artigo: Arruda et al. (2025)" + ANSI_CYAN + "                                           ║" + ANSI_RESET);
        System.out.println(ANSI_CYAN + "║  📖 The Evolution of Cloud Ecosystems: AWS, Azure, and GCP (2008-2025)" + ANSI_CYAN + "     ║" + ANSI_RESET);
        System.out.println(ANSI_CYAN + "║  ❓ 12 Questões de Competência" + ANSI_CYAN + "                                                         ║" + ANSI_RESET);
        System.out.println(ANSI_CYAN + "╚═══════════════════════════════════════════════════════════════════════════════╝" + ANSI_RESET);

        try {
            System.out.println(ANSI_YELLOW + "\n📝 PASSO 1: Construindo a ontologia..." + ANSI_RESET);
            CloudEcoOntology builder = new CloudEcoOntology();

            System.out.println(ANSI_YELLOW + "📝 Salvando a ontologia em arquivos..." + ANSI_RESET);
            builder.saveBothFormats(OUTPUT_DIR);

            System.out.println("\n" + ANSI_GREEN + "╔═══════════════════════════════════════════════════════════════════════════════╗" + ANSI_RESET);
            System.out.println(ANSI_GREEN + "║  ✅ Construção da ontologia concluída!" + ANSI_RESET + ANSI_GREEN + "                                                  ║" + ANSI_RESET);
            System.out.println(ANSI_GREEN + "║  📄 Arquivos gerados:" + ANSI_RESET + ANSI_GREEN + "                                                                    ║" + ANSI_RESET);
            System.out.println(ANSI_GREEN + "║    - " + OUTPUT_DIR + "cloudeco-ontology.rdf" + ANSI_RESET + ANSI_GREEN + "  ║" + ANSI_RESET);
            System.out.println(ANSI_GREEN + "║    - " + OUTPUT_DIR + "cloudeco-ontology.owl" + ANSI_RESET + ANSI_GREEN + "  ║" + ANSI_RESET);
            System.out.println(ANSI_GREEN + "╚═══════════════════════════════════════════════════════════════════════════════╝" + ANSI_RESET);

            System.out.println(ANSI_YELLOW + "\n📊 PASSO 2: Resumo Estatístico da Ontologia:" + ANSI_RESET);
            System.out.println("  ┌────────────────────────────────────────────────────────────────────────────────────┐");
            System.out.println("  │  🏛️  Classes: 60+ classes organizadas em 7 categorias                             │");
            System.out.println("  │  🔗 Propriedades de Objeto: 20 propriedades                                      │");
            System.out.println("  │  📊 Propriedades de Dados: 14 propriedades                                       │");
            System.out.println("  │  👤 Indivíduos: 50+ indivíduos distribuídos pelas classes                         │");
            System.out.println("  │  📖 5 paradigmas tecnológicos (2008-2025)                                        │");
            System.out.println("  │  ☁️ 3 plataformas: AWS, Azure, GCP                                               │");
            System.out.println("  │  ⚙️  17 serviços AWS, 13 Azure, 14 GCP                                            │");
            System.out.println("  │  ❓ 12 Questões de Competência respondidas                                       │");
            System.out.println("  └────────────────────────────────────────────────────────────────────────────────────┘");

            System.out.println(ANSI_YELLOW + "\n📁 Arquivos gerados no diretório:" + ANSI_RESET);
            System.out.println("   " + OUTPUT_DIR);
            System.out.println("   ├── cloudeco-ontology.rdf  (formato RDF/XML)");
            System.out.println("   └── cloudeco-ontology.owl  (formato OWL)");

            System.out.println("\n" + ANSI_GREEN + "╔═══════════════════════════════════════════════════════════════════════════════╗" + ANSI_RESET);
            System.out.println(ANSI_GREEN + "║  🎯 CloudEco-Ontology - Construção Finalizada com Sucesso!                    ║" + ANSI_RESET);
            System.out.println(ANSI_GREEN + "║  ✅ Todas as 12 Questões de Competência podem ser respondidas!                ║" + ANSI_RESET);
            System.out.println(ANSI_GREEN + "╚═══════════════════════════════════════════════════════════════════════════════╝" + ANSI_RESET);

        } catch (Exception e) {
            System.err.println(ANSI_RED + "\n❌ ERRO FATAL: " + e.getMessage() + ANSI_RESET);
            e.printStackTrace();
        }
    }
}