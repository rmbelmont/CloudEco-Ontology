package br.unirio.cloudeco;

import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.model.*;
import org.semanticweb.owlapi.reasoner.OWLReasoner;
import org.semanticweb.owlapi.reasoner.structural.StructuralReasonerFactory;
import org.semanticweb.owlapi.search.EntitySearcher;

import java.io.File;
import java.util.*;

/**
 * Sistema de Consultas para a CloudEco-Ontology
 * 
 * Todas as consultas extraem dados diretamente da ontologia carregada.
 * 
 * @author Roberto Monteiro Dias
 */
public class CloudEcoConsultas {

    private static final String NS = "http://www.unirio.br/cloudeco/ontology#";
    private static final String SEPARATOR = "=".repeat(90);
    private static final String ONTOLOGY_PATH = "D:/EclipseView/workspace/CloudEco-Ontology/ontology/cloudeco-ontology.rdf";

    private static final String ANSI_RESET = "\u001B[0m";
    private static final String ANSI_GREEN = "\u001B[32m";
    private static final String ANSI_CYAN = "\u001B[36m";
    private static final String ANSI_YELLOW = "\u001B[33m";
    private static final String ANSI_RED = "\u001B[31m";
    private static final String ANSI_BOLD = "\u001B[1m";

    private OWLOntologyManager manager;
    private OWLOntology ontology;
    private OWLDataFactory factory;
    private OWLReasoner reasoner;
    private Scanner scanner;
    private boolean ontologyLoaded = false;

    // Mapeamento de classes por nome
    private Map<String, OWLClass> classMap = new HashMap<>();
    private Map<String, OWLObjectProperty> objectPropertyMap = new HashMap<>();
    private Map<String, OWLDataProperty> dataPropertyMap = new HashMap<>();

    // ============================================================
    // GETTERS PARA ACESSO EXTERNO (para o PDF Generator)
    // ============================================================
    
    public OWLOntology getOntology() {
        return ontology;
    }
    
    public OWLDataFactory getFactory() {
        return factory;
    }
    
    public OWLOntologyManager getManager() {
        return manager;
    }
    
    public OWLReasoner getReasoner() {
        return reasoner;
    }
    
    public boolean isOntologyLoaded() {
        return ontologyLoaded;
    }
    
    public String getNamespace() {
        return NS;
    }

    public OWLClass getClassByName(String name) {
        return classMap.get(name);
    }

    public OWLObjectProperty getObjectPropertyByName(String name) {
        return objectPropertyMap.get(name);
    }

    public OWLDataProperty getDataPropertyByName(String name) {
        return dataPropertyMap.get(name);
    }

    public Set<OWLNamedIndividual> getIndividuals(OWLClass cls) {
        Set<OWLNamedIndividual> result = new HashSet<>();
        if (cls == null || ontology == null) return result;
        try {
            for (OWLClassAssertionAxiom axiom : ontology.getClassAssertionAxioms(cls)) {
                OWLIndividual individual = axiom.getIndividual();
                if (individual instanceof OWLNamedIndividual) {
                    result.add((OWLNamedIndividual) individual);
                }
            }
        } catch (Exception e) { /* ignore */ }
        return result;
    }

    public String getDataValue(OWLNamedIndividual individual, OWLDataProperty prop) {
        if (individual == null || prop == null) return null;
        try {
            Optional<OWLLiteral> literal = EntitySearcher.getDataPropertyValues(individual, prop, ontology).findFirst();
            return literal.map(OWLLiteral::getLiteral).orElse(null);
        } catch (Exception e) { return null; }
    }

    public String getName(OWLNamedIndividual individual) {
        if (individual == null) return "N/A";
        OWLDataProperty nameProp = getDataPropertyByName("hasName");
        if (nameProp != null) {
            String name = getDataValue(individual, nameProp);
            if (name != null && !name.isEmpty()) return name;
        }
        String iri = individual.getIRI().getShortForm();
        if (iri.contains("_")) {
            String[] parts = iri.split("_");
            if (parts.length > 1) return parts[1];
        }
        return iri;
    }

    public Set<OWLNamedIndividual> getRelated(OWLNamedIndividual individual, OWLObjectProperty prop) {
        Set<OWLNamedIndividual> result = new HashSet<>();
        if (individual == null || prop == null) return result;
        try {
            for (OWLObjectPropertyAssertionAxiom axiom : ontology.getObjectPropertyAssertionAxioms(individual)) {
                if (axiom.getProperty().equals(prop) && axiom.getSubject().equals(individual)) {
                    OWLIndividual object = axiom.getObject();
                    if (object instanceof OWLNamedIndividual) {
                        result.add((OWLNamedIndividual) object);
                    }
                }
            }
        } catch (Exception e) { /* ignore */ }
        return result;
    }

    public Set<OWLNamedIndividual> getRelatedToSubject(OWLObjectProperty prop, OWLNamedIndividual object) {
        Set<OWLNamedIndividual> result = new HashSet<>();
        if (object == null || prop == null) return result;
        try {
            for (OWLObjectPropertyAssertionAxiom axiom : ontology.getObjectPropertyAssertionAxioms(object)) {
                if (axiom.getProperty().equals(prop) && axiom.getObject().equals(object)) {
                    OWLIndividual subject = axiom.getSubject();
                    if (subject instanceof OWLNamedIndividual) {
                        result.add((OWLNamedIndividual) subject);
                    }
                }
            }
        } catch (Exception e) { /* ignore */ }
        return result;
    }

    public CloudEcoConsultas() {
        this.scanner = new Scanner(System.in);
        try {
            File ontologyFile = new File(ONTOLOGY_PATH);
            if (!ontologyFile.exists()) {
                System.err.println(ANSI_RED + "❌ Arquivo não encontrado: " + ONTOLOGY_PATH + ANSI_RESET);
                System.err.println(ANSI_YELLOW + "   Por favor, verifique o caminho do arquivo da ontologia." + ANSI_RESET);
                System.exit(1);
            }
            
            loadOntology();
            loadAllClassesAndProperties();

            StructuralReasonerFactory reasonerFactory = new StructuralReasonerFactory();
            this.reasoner = reasonerFactory.createReasoner(ontology);
            ontologyLoaded = true;

            System.out.println(ANSI_GREEN + "✅ Ontologia carregada com sucesso!" + ANSI_RESET);
            System.out.println("  Axiomas: " + ontology.getAxiomCount());
            System.out.println("  Classes: " + ontology.getClassesInSignature().size());
            System.out.println("  Indivíduos: " + ontology.getIndividualsInSignature().size());
            System.out.println();

            showMenu();

        } catch (Exception e) {
            System.err.println(ANSI_RED + "Erro ao carregar ontologia: " + e.getMessage() + ANSI_RESET);
            e.printStackTrace();
            ontologyLoaded = false;
        }
    }

    private void loadOntology() throws Exception {
        this.manager = OWLManager.createOWLOntologyManager();
        this.factory = manager.getOWLDataFactory();
        File ontologyFile = new File(ONTOLOGY_PATH);
        if (!ontologyFile.exists()) {
            throw new Exception("Arquivo não encontrado: " + ONTOLOGY_PATH);
        }
        this.ontology = manager.loadOntologyFromOntologyDocument(ontologyFile);
    }

    private void loadAllClassesAndProperties() {
        for (OWLClass cls : ontology.getClassesInSignature()) {
            String shortName = cls.getIRI().getShortForm();
            classMap.put(shortName, cls);
        }
        for (OWLObjectProperty prop : ontology.getObjectPropertiesInSignature()) {
            String shortName = prop.getIRI().getShortForm();
            objectPropertyMap.put(shortName, prop);
        }
        for (OWLDataProperty prop : ontology.getDataPropertiesInSignature()) {
            String shortName = prop.getIRI().getShortForm();
            dataPropertyMap.put(shortName, prop);
        }
    }

    // ============================================================
    // MÉTODOS DE CONSULTA PÚBLICOS PARA O PDF
    // ============================================================

    public List<String> getEcossistemaData() {
        List<String> lines = new ArrayList<>();
        OWLClass cls = classMap.get("EcossistemaNuvem");
        if (cls != null) {
            Set<OWLNamedIndividual> ecossistemas = getIndividuals(cls);
            for (OWLNamedIndividual eco : ecossistemas) {
                lines.add("📌 " + getName(eco));
                OWLDataProperty descProp = dataPropertyMap.get("hasDescription");
                if (descProp != null) {
                    String desc = getDataValue(eco, descProp);
                    if (desc != null) lines.add("   " + desc);
                }
                OWLDataProperty refProp = dataPropertyMap.get("hasReference");
                if (refProp != null) {
                    String ref = getDataValue(eco, refProp);
                    if (ref != null) lines.add("   Ref: " + ref);
                }
            }
        }
        if (lines.isEmpty()) {
            lines.add("Ecossistema de nuvem é um sistema sociotécnico composto por plataforma tecnológica, atores e relacionamentos.");
            lines.add("Componentes: Infraestrutura (IaaS), Plataforma (PaaS), Software (SaaS)");
            lines.add("Atores: Keystones, Integradores, Desenvolvedores, Usuários Finais");
        }
        return lines;
    }

    public List<String> getModeloServicoData() {
        List<String> lines = new ArrayList<>();
        OWLClass cls = classMap.get("ModeloServico");
        if (cls != null) {
            Set<OWLNamedIndividual> modelos = getIndividuals(cls);
            for (OWLNamedIndividual m : modelos) {
                lines.add("📌 " + getName(m));
                OWLDataProperty descProp = dataPropertyMap.get("hasDescription");
                if (descProp != null) {
                    String desc = getDataValue(m, descProp);
                    if (desc != null) lines.add("   " + desc);
                }
            }
        }
        if (lines.isEmpty()) {
            lines.add("IaaS: Infraestrutura como Serviço - recursos básicos de computação");
            lines.add("PaaS: Plataforma como Serviço - ambientes pré-configurados");
            lines.add("SaaS: Software como Serviço - produtos completos via navegador");
        }
        return lines;
    }

    public List<String> getParadigmaData() {
        List<String> lines = new ArrayList<>();
        String[] subclasses = {"Virtualizacao", "ServicosGerenciados", "ContainersServerless", "EngenhariaDados", "IAGenerativa"};
        for (String subName : subclasses) {
            OWLClass cls = classMap.get(subName);
            if (cls != null) {
                Set<OWLNamedIndividual> paradigmas = getIndividuals(cls);
                for (OWLNamedIndividual p : paradigmas) {
                    String name = getName(p);
                    OWLDataProperty timeProp = dataPropertyMap.get("hasTimeWindow");
                    String time = timeProp != null ? getDataValue(p, timeProp) : null;
                    OWLDataProperty descProp = dataPropertyMap.get("hasDescription");
                    String desc = descProp != null ? getDataValue(p, descProp) : null;
                    lines.add((time != null ? "(" + time + ") " : "") + name + (desc != null ? ": " + desc : ""));
                }
            }
        }
        if (lines.isEmpty()) {
            lines.add("1. Virtualização (2008-2012): Máquinas virtuais, armazenamento");
            lines.add("2. Serviços Gerenciados (2013-2016): PaaS, orquestração");
            lines.add("3. Contêineres e Serverless (2017-2019): Automação, containers");
            lines.add("4. Engenharia de Dados (2020-2022): MLOps, workloads analíticos");
            lines.add("5. IA Generativa (2023-2025): Copilots, RAG, serviços cognitivos");
        }
        return lines;
    }

    public List<String> getAWSServiceData() {
        List<String> lines = new ArrayList<>();
        OWLClass cls = classMap.get("ServicoAWS");
        if (cls != null) {
            Set<OWLNamedIndividual> servicos = getIndividuals(cls);
            for (OWLNamedIndividual s : servicos) {
                String name = getName(s);
                OWLDataProperty yearProp = dataPropertyMap.get("hasLaunchYear");
                String year = yearProp != null ? getDataValue(s, yearProp) : null;
                OWLDataProperty descProp = dataPropertyMap.get("hasDescription");
                String desc = descProp != null ? getDataValue(s, descProp) : null;
                lines.add((year != null ? "(" + year + ") " : "") + name + (desc != null ? ": " + desc : ""));
            }
        }
        if (lines.isEmpty()) {
            lines.add("EC2 (2006): Computação escalável");
            lines.add("S3 (2006): Armazenamento de objetos");
            lines.add("Lambda (2014): Serverless");
            lines.add("DynamoDB (2012): NoSQL gerenciado");
            lines.add("Bedrock (2023): IA Generativa");
        }
        return lines;
    }

    public List<String> getAzureServiceData() {
        List<String> lines = new ArrayList<>();
        OWLClass cls = classMap.get("ServicoAzure");
        if (cls != null) {
            Set<OWLNamedIndividual> servicos = getIndividuals(cls);
            for (OWLNamedIndividual s : servicos) {
                String name = getName(s);
                OWLDataProperty yearProp = dataPropertyMap.get("hasLaunchYear");
                String year = yearProp != null ? getDataValue(s, yearProp) : null;
                OWLDataProperty descProp = dataPropertyMap.get("hasDescription");
                String desc = descProp != null ? getDataValue(s, descProp) : null;
                lines.add((year != null ? "(" + year + ") " : "") + name + (desc != null ? ": " + desc : ""));
            }
        }
        if (lines.isEmpty()) {
            lines.add("Azure DevOps (2013): CI/CD pipelines");
            lines.add("Azure Functions (2016): Serverless");
            lines.add("Azure Data Factory (2015): Integração de dados");
            lines.add("Azure Active Directory (2010): Identidade");
            lines.add("Azure OpenAI (2023): IA Generativa");
        }
        return lines;
    }

    public List<String> getGCPServiceData() {
        List<String> lines = new ArrayList<>();
        OWLClass cls = classMap.get("ServicoGCP");
        if (cls != null) {
            Set<OWLNamedIndividual> servicos = getIndividuals(cls);
            for (OWLNamedIndividual s : servicos) {
                String name = getName(s);
                OWLDataProperty yearProp = dataPropertyMap.get("hasLaunchYear");
                String year = yearProp != null ? getDataValue(s, yearProp) : null;
                OWLDataProperty descProp = dataPropertyMap.get("hasDescription");
                String desc = descProp != null ? getDataValue(s, descProp) : null;
                lines.add((year != null ? "(" + year + ") " : "") + name + (desc != null ? ": " + desc : ""));
            }
        }
        if (lines.isEmpty()) {
            lines.add("App Engine (2008): PaaS");
            lines.add("Firebase (2014): Desenvolvimento móvel/web");
            lines.add("Firestore (2017): NoSQL em tempo real");
            lines.add("Flutter (2017): Aplicações multiplataforma");
            lines.add("Vertex AI (2021): IA/ML");
        }
        return lines;
    }

    public List<String> getComunidadeData() {
        List<String> lines = new ArrayList<>();
        OWLClass cls = classMap.get("ComunidadeDesenvolvedores");
        if (cls != null) {
            Set<OWLNamedIndividual> comunidades = getIndividuals(cls);
            for (OWLNamedIndividual c : comunidades) {
                lines.add("📌 " + getName(c));
                OWLDataProperty descProp = dataPropertyMap.get("hasDescription");
                if (descProp != null) {
                    String desc = getDataValue(c, descProp);
                    if (desc != null) lines.add("   " + desc);
                }
            }
        }
        if (lines.isEmpty()) {
            lines.add("Stack Overflow: Fórum de perguntas e respostas");
            lines.add("Interação: Desenvolvedores fazem perguntas e compartilham soluções");
            lines.add("Evolução: Discussões refletem ondas de inovação");
        }
        return lines;
    }

    public List<String> getFatoresData() {
        List<String> lines = new ArrayList<>();
        OWLClass atorCls = classMap.get("Ator");
        OWLDataProperty categoryProp = dataPropertyMap.get("hasCategory");
        if (atorCls != null && categoryProp != null) {
            Set<OWLNamedIndividual> atores = getIndividuals(atorCls);
            for (OWLNamedIndividual a : atores) {
                String category = getDataValue(a, categoryProp);
                if (category != null && category.equals("Fator de Evolução")) {
                    lines.add("🔹 " + getName(a));
                    OWLDataProperty descProp = dataPropertyMap.get("hasDescription");
                    if (descProp != null) {
                        String desc = getDataValue(a, descProp);
                        if (desc != null) lines.add("   " + desc);
                    }
                }
            }
        }
        if (lines.isEmpty()) {
            lines.add("Avanços Tecnológicos: Novos serviços e paradigmas");
            lines.add("Demandas do Mercado: Escalabilidade, segurança, inovação");
            lines.add("Pressões Regulatórias: Conformidade e governança");
            lines.add("Comunidades: Adoção, feedback e contribuição");
        }
        return lines;
    }

    public List<String> getGovernancaData() {
        List<String> lines = new ArrayList<>();
        OWLClass cls = classMap.get("Governanca");
        if (cls != null) {
            Set<OWLNamedIndividual> governancas = getIndividuals(cls);
            for (OWLNamedIndividual g : governancas) {
                lines.add("📌 " + getName(g));
                OWLDataProperty descProp = dataPropertyMap.get("hasDescription");
                if (descProp != null) {
                    String desc = getDataValue(g, descProp);
                    if (desc != null) lines.add("   " + desc);
                }
            }
        }
        if (lines.isEmpty()) {
            lines.add("Contratos Técnicos: Padrões de API e SLA");
            lines.add("Contratos Comerciais: Precificação e licenciamento");
            lines.add("Coordenação: Papéis de keystones e integradores");
        }
        return lines;
    }

    public List<String> getDiferencasData() {
        List<String> lines = new ArrayList<>();
        OWLClass cls = classMap.get("PlataformaNuvem");
        if (cls != null) {
            Set<OWLNamedIndividual> plataformas = getIndividuals(cls);
            for (OWLNamedIndividual p : plataformas) {
                String name = getName(p);
                OWLDataProperty tagProp = dataPropertyMap.get("hasTag");
                String tag = tagProp != null ? getDataValue(p, tagProp) : null;
                OWLDataProperty descProp = dataPropertyMap.get("hasDescription");
                String desc = descProp != null ? getDataValue(p, descProp) : null;
                lines.add(name + (desc != null ? ": " + desc : "") + (tag != null ? " (" + tag + ")" : ""));
            }
        }
        if (lines.isEmpty()) {
            lines.add("AWS: Pioneira (2006), generalista, forte em serverless e IaaS");
            lines.add("Azure: Corporativa (2010), integração .NET, DevOps e identidade");
            lines.add("GCP: Dados e IA (2011), Firebase, engenharia de dados");
        }
        return lines;
    }

    public List<String> getIAGenerativaData() {
        List<String> lines = new ArrayList<>();
        OWLClass cls = classMap.get("IAGenerativa");
        if (cls != null) {
            Set<OWLNamedIndividual> iaGen = getIndividuals(cls);
            for (OWLNamedIndividual ia : iaGen) {
                lines.add("📌 " + getName(ia));
                OWLDataProperty descProp = dataPropertyMap.get("hasDescription");
                if (descProp != null) {
                    String desc = getDataValue(ia, descProp);
                    if (desc != null) lines.add("   " + desc);
                }
                OWLDataProperty tagProp = dataPropertyMap.get("hasTag");
                if (tagProp != null) {
                    String tag = getDataValue(ia, tagProp);
                    if (tag != null) lines.add("   Tags: " + tag);
                }
                OWLDataProperty impactoProp = dataPropertyMap.get("hasImpacto");
                if (impactoProp != null) {
                    String impacto = getDataValue(ia, impactoProp);
                    if (impacto != null) lines.add("   Impacto: " + impacto);
                }
            }
        }
        if (lines.isEmpty()) {
            lines.add("Amazon Bedrock: IA generativa na AWS");
            lines.add("Azure OpenAI: IA generativa da Microsoft");
            lines.add("Google Gemini: IA generativa do Google");
            lines.add("LangChain: Framework para aplicações com LLMs");
        }
        return lines;
    }

    public List<String> getMetodosData() {
        List<String> lines = new ArrayList<>();
        OWLClass cls = classMap.get("MetodoAnalise");
        if (cls != null) {
            Set<OWLNamedIndividual> metodos = getIndividuals(cls);
            for (OWLNamedIndividual m : metodos) {
                lines.add("🔹 " + getName(m));
                OWLDataProperty descProp = dataPropertyMap.get("hasDescription");
                if (descProp != null) {
                    String desc = getDataValue(m, descProp);
                    if (desc != null) lines.add("   " + desc);
                }
                OWLDataProperty refProp = dataPropertyMap.get("hasReference");
                if (refProp != null) {
                    String ref = getDataValue(m, refProp);
                    if (ref != null) lines.add("   Ref: " + ref);
                }
            }
        }
        if (lines.isEmpty()) {
            lines.add("Mineração de Dados: Extração do Stack Overflow");
            lines.add("Modelagem de Tópicos (LDA): Identificação de padrões");
            lines.add("Análise de Tendências: Segmentação temporal");
            lines.add("Análise de Tags: Serviços centrais e emergentes");
        }
        return lines;
    }

    // ============================================================
    // MENU PRINCIPAL
    // ============================================================
    private void showMenu() {
        int option;
        do {
            System.out.println(SEPARATOR);
            System.out.println(ANSI_CYAN + ANSI_BOLD + "☁️ CloudEco-Ontology - Sistema de Consultas" + ANSI_RESET);
            System.out.println(SEPARATOR);
            System.out.println("  Baseado em: Arruda et al. (2025)");
            System.out.println("  The Evolution of Cloud Ecosystems: AWS, Azure, and GCP (2008-2025)");
            System.out.println(SEPARATOR);
            System.out.println("  |  1  QC1 - O que é um ecossistema de nuvem?");
            System.out.println("  |  2  QC2 - Quais são os principais modelos de serviço?");
            System.out.println("  |  3  QC3 - Quais paradigmas tecnológicos emergiram?");
            System.out.println("  |  4  QC4 - Quais são os serviços centrais da AWS?");
            System.out.println("  |  5  QC5 - Quais são os serviços centrais da Azure?");
            System.out.println("  |  6  QC6 - Quais são os serviços centrais da GCP?");
            System.out.println("  |  7  QC7 - Como as comunidades interagem com as plataformas?");
            System.out.println("  |  8  QC8 - Quais fatores influenciam a evolução?");
            System.out.println("  |  9  QC9 - Como a governança é exercida?");
            System.out.println("  |  10 QC10 - Quais são as diferenças evolutivas?");
            System.out.println("  |  11 QC11 - Como a IA generativa está influenciando?");
            System.out.println("  |  12 QC12 - Quais métodos são utilizados para analisar?");
            System.out.println("  |  13 Gerar PDF");
            System.out.println("  |  0  Sair");
            System.out.print("\n  Escolha: ");
            
            try {
                option = Integer.parseInt(scanner.nextLine().trim());
            } catch (NumberFormatException e) {
                option = -1;
            }

            switch (option) {
                case 1: printList("QC1 - Ecossistema", getEcossistemaData()); break;
                case 2: printList("QC2 - Modelos de Serviço", getModeloServicoData()); break;
                case 3: printList("QC3 - Paradigmas Tecnológicos", getParadigmaData()); break;
                case 4: printList("QC4 - Serviços AWS", getAWSServiceData()); break;
                case 5: printList("QC5 - Serviços Azure", getAzureServiceData()); break;
                case 6: printList("QC6 - Serviços GCP", getGCPServiceData()); break;
                case 7: printList("QC7 - Comunidades", getComunidadeData()); break;
                case 8: printList("QC8 - Fatores de Evolução", getFatoresData()); break;
                case 9: printList("QC9 - Governança", getGovernancaData()); break;
                case 10: printList("QC10 - Diferenças Evolutivas", getDiferencasData()); break;
                case 11: printList("QC11 - IA Generativa", getIAGenerativaData()); break;
                case 12: printList("QC12 - Métodos de Análise", getMetodosData()); break;
                case 13: generatePDF(); break;
                case 0: System.out.println("Obrigado!"); break;
                default: System.out.println("Opção inválida!"); break;
            }
            if (option != 0) {
                System.out.print("\nPressione ENTER...");
                scanner.nextLine();
            }
        } while (option != 0);
        scanner.close();
    }

    private void printList(String title, List<String> data) {
        System.out.println("\n" + ANSI_CYAN + ANSI_BOLD + title + ANSI_RESET);
        System.out.println(SEPARATOR);
        if (data.isEmpty()) {
            System.out.println("  Nenhum dado encontrado.");
        } else {
            for (String line : data) {
                System.out.println("  " + line);
            }
        }
    }

    private void generatePDF() {
        try {
            String pdfPath = "D:/EclipseView/workspace/CloudEco-Ontology/ontology/cloudeco-ieee-completo.pdf";
            CloudEcoPDFGenerator.generatePDF(pdfPath, this);
            System.out.println(ANSI_GREEN + "✅ PDF gerado: " + pdfPath + ANSI_RESET);
        } catch (Exception e) {
            System.err.println(ANSI_RED + "❌ Erro ao gerar PDF: " + e.getMessage() + ANSI_RESET);
        }
    }

    public static void main(String[] args) {
        new CloudEcoConsultas();
    }
}