package br.unirio.cloudeco;

import com.itextpdf.kernel.colors.Color;
import com.itextpdf.kernel.colors.DeviceRgb;
import com.itextpdf.kernel.font.PdfFont;
import com.itextpdf.kernel.font.PdfFontFactory;
import com.itextpdf.kernel.geom.PageSize;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Cell;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;
import com.itextpdf.layout.element.Text;
import com.itextpdf.layout.properties.TextAlignment;
import com.itextpdf.layout.properties.UnitValue;

import java.io.File;
import java.io.IOException;
import java.util.List;

/**
 * Gerador de PDF para a CloudEco-Ontology
 * 
 * Extrai dados diretamente da ontologia através da classe de consultas.
 * 
 * @author Roberto Monteiro Dias
 */
public class CloudEcoPDFGenerator {

    // Cores IEEE
    private static final Color IEEE_BLUE = new DeviceRgb(0, 51, 102);
    private static final Color IEEE_LIGHT_BLUE = new DeviceRgb(220, 235, 250);
    private static final Color IEEE_DARK_GRAY = new DeviceRgb(80, 80, 80);
    private static final Color IEEE_GREEN = new DeviceRgb(0, 130, 80);
    private static final Color IEEE_RED = new DeviceRgb(180, 30, 30);
    private static final Color IEEE_ORANGE = new DeviceRgb(200, 120, 20);
    private static final Color IEEE_PURPLE = new DeviceRgb(100, 50, 150);
    private static final Color IEEE_TEAL = new DeviceRgb(0, 128, 128);
    private static final Color IEEE_CRIMSON = new DeviceRgb(220, 20, 60);
    private static final Color IEEE_NAVY = new DeviceRgb(0, 0, 128);
    private static final Color IEEE_SEA_GREEN = new DeviceRgb(46, 139, 87);
    private static final Color IEEE_GOLD = new DeviceRgb(184, 134, 11);

    private static final Color[] COLORS = {
        IEEE_BLUE, IEEE_GREEN, IEEE_RED, IEEE_TEAL, 
        IEEE_CRIMSON, IEEE_PURPLE, IEEE_NAVY, IEEE_ORANGE,
        IEEE_SEA_GREEN, IEEE_PURPLE, IEEE_BLUE, IEEE_GOLD
    };

    public static void generatePDF(String outputPath, CloudEcoConsultas consultas) throws IOException {
        File outputFile = new File(outputPath);
        if (outputFile.getParentFile() != null) {
            outputFile.getParentFile().mkdirs();
        }

        PdfWriter writer = new PdfWriter(outputFile);
        PdfDocument pdfDoc = new PdfDocument(writer);
        pdfDoc.setDefaultPageSize(PageSize.A4);

        Document document = new Document(pdfDoc);
        document.setMargins(40, 40, 40, 40);

        PdfFont fontNormal = PdfFontFactory.createFont("Helvetica");
        PdfFont fontBold = PdfFontFactory.createFont("Helvetica-Bold");
        PdfFont fontItalic = PdfFontFactory.createFont("Helvetica-Oblique");

        // ============================================
        // CABEÇALHO
        // ============================================

        Paragraph title = new Paragraph("CloudEco-Ontology")
                .setFont(fontBold)
                .setFontSize(22)
                .setTextAlignment(TextAlignment.CENTER)
                .setFontColor(IEEE_BLUE);
        document.add(title);

        Paragraph subtitle = new Paragraph("Ontologia para Ecossistemas de Computacao em Nuvem")
                .setFont(fontBold)
                .setFontSize(14)
                .setTextAlignment(TextAlignment.CENTER)
                .setFontColor(IEEE_DARK_GRAY);
        document.add(subtitle);

        Paragraph authors = new Paragraph()
                .setFont(fontNormal)
                .setFontSize(11)
                .setTextAlignment(TextAlignment.CENTER)
                .setFontColor(IEEE_DARK_GRAY);
        authors.add(new Text("Roberto Monteiro Dias\n").setFont(fontBold));
        authors.add(new Text("Universidade Federal do Estado do Rio de Janeiro (UNIRIO)\n"));
        authors.add(new Text("Email: roberto.dias@edu.unirio.br"));
        document.add(authors);
        document.add(new Paragraph(" ").setFontSize(4));

        Paragraph separator = new Paragraph("_________________________________________________________________________________")
                .setFont(fontNormal)
                .setFontSize(10)
                .setTextAlignment(TextAlignment.CENTER)
                .setFontColor(IEEE_DARK_GRAY);
        document.add(separator);

        Paragraph info = new Paragraph()
                .setTextAlignment(TextAlignment.CENTER)
                .setFontSize(9)
                .setFontColor(IEEE_DARK_GRAY);
        info.add(new Text("Data: ").setFont(fontBold));
        info.add(new Text(java.time.LocalDate.now().toString() + "  ").setFont(fontNormal));
        info.add(new Text("Versao: ").setFont(fontBold));
        info.add(new Text("1.0  ").setFont(fontNormal));
        info.add(new Text("Questoes: ").setFont(fontBold));
        info.add(new Text("12").setFont(fontNormal));
        document.add(info);
        document.add(new Paragraph(" ").setFontSize(8));

        // ============================================
        // RESUMO
        // ============================================

        Paragraph abstractTitle = new Paragraph("Resumo")
                .setFont(fontBold)
                .setFontSize(11)
                .setTextAlignment(TextAlignment.LEFT)
                .setFontColor(IEEE_BLUE);
        document.add(abstractTitle);

        var ontology = consultas.getOntology();
        Paragraph abstractText = new Paragraph(
                "Este artigo apresenta a CloudEco-Ontology, uma ontologia de dominio "
                + "para a compreensao de Ecossistemas de Computacao em Nuvem. Baseada no "
                + "estudo longitudinal de Arruda et al. (2025), a ontologia formaliza 12 "
                + "questoes de competencia que abrangem: ecossistemas, modelos de servico, "
                + "paradigmas tecnologicos, servicos especificos (AWS, Azure, GCP), "
                + "comunidades de desenvolvedores, governanca e fatores de evolucao. "
                + "A ontologia contem " + ontology.getClassesInSignature().size() + " classes, "
                + ontology.getObjectPropertiesInSignature().size() + " propriedades de objeto, "
                + ontology.getDataPropertiesInSignature().size() + " propriedades de dados e "
                + ontology.getIndividualsInSignature().size() + " individuos."
        ).setFont(fontItalic).setFontSize(9).setTextAlignment(TextAlignment.JUSTIFIED);
        document.add(abstractText);

        document.add(new Paragraph(" ").setFontSize(6));

        Paragraph keywords = new Paragraph()
                .setFont(fontNormal)
                .setFontSize(9)
                .setTextAlignment(TextAlignment.LEFT);
        keywords.add(new Text("Palavras-chave ").setFont(fontBold));
        keywords.add(new Text("Computacao em Nuvem, AWS, Azure, GCP, Ecossistemas de Software, ")
                .setFont(fontItalic));
        keywords.add(new Text("Ontologia, Comunidades de Desenvolvedores.").setFont(fontItalic));
        document.add(keywords);
        document.add(new Paragraph(" ").setFontSize(8));

        document.add(separator);
        document.add(new Paragraph(" ").setFontSize(8));

        // ============================================
        // TITULO DA SECAO
        // ============================================

        Paragraph sectionTitle = new Paragraph("I. QUESTOES DE COMPETENCIA")
                .setFont(fontBold)
                .setFontSize(14)
                .setTextAlignment(TextAlignment.LEFT)
                .setFontColor(IEEE_BLUE);
        document.add(sectionTitle);
        document.add(new Paragraph(" ").setFontSize(6));

        // ============================================
        // TABELA COM AS 12 QUESTOES
        // ============================================

        Table table = new Table(UnitValue.createPercentArray(new float[]{50, 50}));
        table.setWidth(UnitValue.createPercentValue(100));

        // Dados das questoes
        String[] questionIds = {"QC1", "QC2", "QC3", "QC4", "QC5", "QC6", "QC7", "QC8", "QC9", "QC10", "QC11", "QC12"};
        String[] questionNames = {
            "O que e um ecossistema de nuvem?",
            "Quais sao os principais modelos de servico em nuvem?",
            "Quais paradigmas tecnologicos emergiram?",
            "Quais sao os servicos centrais da AWS?",
            "Quais sao os servicos centrais da Azure?",
            "Quais sao os servicos centrais da GCP?",
            "Como as comunidades interagem com as plataformas?",
            "Quais fatores influenciam a evolucao?",
            "Como a governanca e exercida?",
            "Quais sao as diferencas evolutivas?",
            "Como a IA generativa esta influenciando?",
            "Quais metodos sao utilizados para analisar?"
        };

        List<String>[] questionData = new List[] {
            consultas.getEcossistemaData(),
            consultas.getModeloServicoData(),
            consultas.getParadigmaData(),
            consultas.getAWSServiceData(),
            consultas.getAzureServiceData(),
            consultas.getGCPServiceData(),
            consultas.getComunidadeData(),
            consultas.getFatoresData(),
            consultas.getGovernancaData(),
            consultas.getDiferencasData(),
            consultas.getIAGenerativaData(),
            consultas.getMetodosData()
        };

        for (int i = 0; i < 12; i++) {
            processQuestion(table, questionIds[i], questionNames[i], questionData[i], COLORS[i % COLORS.length], fontNormal, fontBold, fontItalic);
        }

        document.add(table);

        // ============================================
        // REFERENCIAS
        // ============================================

        document.add(new Paragraph(" ").setFontSize(10));
        document.add(separator);

        Paragraph refTitle = new Paragraph("REFERENCIAS")
                .setFont(fontBold)
                .setFontSize(11)
                .setTextAlignment(TextAlignment.LEFT)
                .setFontColor(IEEE_BLUE);
        document.add(refTitle);

        Paragraph references = new Paragraph()
                .setTextAlignment(TextAlignment.LEFT)
                .setFontSize(8)
                .setFontColor(IEEE_DARK_GRAY);

        references.add(new Text("[1] ").setFont(fontBold));
        references.add(new Text("A. S. Arruda, R. P. Santos, P. N. S. Moura, A. C. F. Alvim, and L. O. F. Moraes, ")
                .setFont(fontNormal));
        references.add(new Text("\"The Evolution of Cloud Ecosystems: How AWS, Azure, and GCP Transformed Between 2008 and 2025,\" ")
                .setFont(fontNormal));
        references.add(new Text("UNIRIO").setFont(fontItalic));
        references.add(new Text(", Rio de Janeiro, 2025.\n").setFont(fontNormal));

        references.add(new Text("[2] ").setFont(fontBold));
        references.add(new Text("P. Mell and T. Grance, \"The NIST Definition of Cloud Computing,\" ")
                .setFont(fontNormal));
        references.add(new Text("NIST Special Publication 800-145").setFont(fontItalic));
        references.add(new Text(", 2011.\n").setFont(fontNormal));

        references.add(new Text("[3] ").setFont(fontBold));
        references.add(new Text("M. Armbrust et al., \"A view of cloud computing,\" ")
                .setFont(fontNormal));
        references.add(new Text("Communications of the ACM").setFont(fontItalic));
        references.add(new Text(", vol. 53, no. 4, pp. 50-58, 2010.\n").setFont(fontNormal));

        references.add(new Text("[4] ").setFont(fontBold));
        references.add(new Text("D. G. Messerschmitt and C. Szyperski, ")
                .setFont(fontNormal));
        references.add(new Text("Software Ecosystem: Understanding an Indispensable Technology and Industry")
                .setFont(fontItalic));
        references.add(new Text(", MIT Press, 2003.\n").setFont(fontNormal));

        document.add(references);

        // ============================================
        // RODAPE
        // ============================================

        document.add(new Paragraph(" ").setFontSize(6));
        Paragraph footer = new Paragraph()
                .setTextAlignment(TextAlignment.CENTER)
                .setFontSize(7)
                .setFontColor(IEEE_DARK_GRAY);
        footer.add(new Text("© 2026 CloudEco-Ontology. ").setFont(fontNormal));
        footer.add(new Text("Baseado em Arruda et al. (2025). ").setFont(fontItalic));
        footer.add(new Text("Versao 1.0").setFont(fontNormal));
        document.add(footer);

        document.close();
        pdfDoc.close();
    }

    // ============================================================
    // PROCESSAMENTO DA QUESTAO
    // ============================================================

    private static void processQuestion(Table table, String qcId, String question, List<String> data,
                                        Color color, PdfFont fontNormal, PdfFont fontBold, PdfFont fontItalic) {

        Cell questionCell = new Cell();
        questionCell.setBackgroundColor(color);
        questionCell.setPadding(12);
        questionCell.setBorder(null);

        Paragraph qcIdP = new Paragraph(qcId)
                .setFont(fontBold)
                .setFontSize(16)
                .setFontColor(DeviceRgb.WHITE)
                .setTextAlignment(TextAlignment.CENTER);
        questionCell.add(qcIdP);

        Paragraph qcQuestion = new Paragraph(question)
                .setFont(fontNormal)
                .setFontSize(9)
                .setFontColor(DeviceRgb.WHITE)
                .setTextAlignment(TextAlignment.LEFT)
                .setMarginTop(8);
        questionCell.add(qcQuestion);

        table.addCell(questionCell);

        Cell answerCell = new Cell();
        answerCell.setPadding(12);
        answerCell.setBorder(null);
        answerCell.setBackgroundColor(IEEE_LIGHT_BLUE);

        Paragraph answerTitle = new Paragraph("RESPOSTA")
                .setFont(fontBold)
                .setFontSize(10)
                .setFontColor(IEEE_DARK_GRAY)
                .setTextAlignment(TextAlignment.LEFT);
        answerCell.add(answerTitle);

        if (data == null || data.isEmpty()) {
            Paragraph noData = new Paragraph("Nenhum dado disponivel na ontologia")
                    .setFont(fontItalic)
                    .setFontSize(8)
                    .setFontColor(IEEE_DARK_GRAY);
            answerCell.add(noData);
        } else {
            int maxItems = Math.min(data.size(), 8);
            for (int i = 0; i < maxItems; i++) {
                Paragraph itemP = new Paragraph();
                itemP.add(new Text("  ").setFont(fontNormal).setFontSize(7));
                itemP.add(new Text(data.get(i)).setFont(fontNormal).setFontSize(7));
                answerCell.add(itemP);
            }
            if (data.size() > 8) {
                Paragraph more = new Paragraph()
                        .add(new Text("  ... e mais " + (data.size() - 8) + " itens").setFont(fontItalic).setFontSize(7));
                answerCell.add(more);
            }
        }

        table.addCell(answerCell);
    }
}